/** 
 * \author Stojanco Stamkov
 * \author Julian Fuerstenau
 * \date 08.04.2006
 * \file Instruction.h
 * \brief All instructions are defined here
 *
 * This file contains the definitions for the 10 instructions that a bug needs to understand
 * There is a purely virtual class Instruction defined, from which all the instruction sub-classes
 * are defined. Virtual methods will be documented only for the base class
 */
#ifndef __INSTRUCTION_H
#define __INSTRUCTION_H


namespace BugSim {
#ifndef __CONDITION
#define __CONDITION
/**
* \brief The enum condition specifies the 15 conditions that can be sensed by the bugs
*
*enum condition is mapped in int for the needs of the instruction constructor in this order:
*Marker0 -> 0
*Marker1 -> 1
*Marker2 -> 2
*Marker3 -> 3
*Marker4 -> 4
*Marker5 -> 5
*Friend -> 6
*Foe -> 7
*FriendWithFood -> 8
*FoeWithFood -> 9
*Food -> 10
*Rock -> 11
*FoeMarker -> 12
*Home -> 13
*FoeHome -> 14
*/
enum condition {Marker0,Marker1,Marker2,Marker3,Marker4,Marker5, Friend, Foe, FriendWithFood,
 FoeWithFood, Food, Rock, FoeMarker, Home, FoeHome};

#endif

#ifndef __BUG_COLOR__
#define __BUG_COLOR__
/**
* \brief enum Color specifies the color of a bug or a color of a base 
*/
typedef enum {Red, Black, NoColor} Color;
#endif///__BUG_COLOR__


#ifndef __LEFTRIGHT__
#define __LEFTRIGHT__
/**
* \brief enum leftright specifies the direction of turning of a bug
*/
enum leftright {Left,Right};
#endif

#ifndef __SENSING__
#define __SENSING__
/**
* \brief enum sensing specifies the direction of sensing of a bug
*
*sensing is mapped in int for the needs of the instruction constructor in this order:
*Here -> 0
*LeftAhead -> 1
*RightAhead -> 2
*Ahead -> 3
*/
enum sensing {Here,LeftAhead,RightAhead,Ahead};

#endif



/** \brief This is a purely virtual class from which all the instruction sub-classes are derived
*
* As a purely virtual class, there can be no instances of this class. Instead, it is used to provide
* a basis for all the separate instruction classes to inherit.
*/
class Instruction {
private:
/** \brief A virtual method which checks the validity of the instruction.
*
* Checks the parameters of the instruction. If the instruction is invalid, it sets bool valid to false
*
* \param It takes as input an integer array with the parameters of the instruction
* \return If the instruction is valid, it returns true, else it returns false
*/
    virtual bool Validate(int operands[])=0;
protected:
/** \brief A boolean which tells us whether the instruction is valid
*
* If bool valid is false, the instruction is invalid, else it is valid
*/
    bool valid;      
public:
/** \brief The virtual destructor
*/
	virtual ~Instruction()=0; 
/** \brief The empty constructor
*/
    Instruction();
/** \brief A virtual method which executes the instuction on a given bug
*
* It calls Validate, and if the instruction is valid it executes it over the given bug
*
* \param The bug that the instruction will be executed upon
* \return It returns 0 if the execution was successful, and other int if it wasn't
*/
	virtual int Execute(Bug& b)=0;
#ifdef DEBUG
/** \brief A debugging-only virtual method
*
* If DEBUG is defined as a macro, this method prints information about the instruction
*/
    virtual void printDebug()=0;
#endif
	
};
/** \brief A class for the Goto instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class.
* It has distinct constructors and additional attributes. Goto sets the next state of a bug when executed
*/
class InstGoTo:public Instruction
{
private:
 	bool Validate(int operands[]);
    int nextState;
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the next state
*/
    int arr[1];
public:
    InstGoTo();   
    ~InstGoTo();
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands 
* \param The maximum number of states, needed to error-check the input
*/
	InstGoTo(int operands[],int MaxStates);
	int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
    InstGoTo NewMe(int MaxStates);
#ifdef DEBUG
    void printDebug();
#endif
};
/** \brief A class for the Mark instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. Mark sets a marker in the cell the bug is in when executed
* and sets a next state
*/
class InstMark:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the mark code to be set
* direction and arr[1] is the next state
*/
        int arr[2];
/** \brief The integer code for the mark (0 to 5)
*/
		int mark;
/** \brief The next state for the bug
*/
		int nextState;
 		bool Validate(int operands[]);
	public:
        InstMark();
        ~InstMark();   
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstMark(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
	    InstMark NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};

/** \brief A class for the Unmark instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. Unmark clears a marker in the cell the bug is in when executed
* and sets a next state
*/
class InstUnmark:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the mark to be removed
* direction and arr[1] is the next state
*/
        int arr[2];
/** \brief The integer code for the mark (0 to 5)
*/
		int mark;
/** \brief The next state for the bug
*/
		int nextState;
 		bool Validate(int operands[]);
	public:
        InstUnmark();
        ~InstUnmark();
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstUnmark(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstUnmark NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};
/** \brief A class for the Turn instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes.  Changes the bug's direction is in when executed and
* sets a next state
*/
class InstTurn:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the turning
* direction and arr[1] is the next state
*/
        int arr[2];
/** \brief The enum that holds the turning direction of the bug
*/
		leftright lr;
/** \brief The next state for the bug
*/
		int nextState;
 		bool Validate(int operands[]);
	public:
        InstTurn();
        ~InstTurn();   
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstTurn(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstTurn NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};
/** \brief A class for the Sense instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. Senses for a condition in a direction, and sets a success or failure
* state depending if the condition is true or false
*/
class InstSense:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the direction to sense in,
* arr[1] is the success state, arr[2] is the failure state, and arr[3] is the sensing condition code
*/
        int arr[4];
/** \brief The code for the sensing direction (0 to 3)
*/
		int senseDir;
/** \brief The success state for the bug
*/
		int successState;
/** \brief The failure state for the bug
*/
		int failureState;
		condition Cond;
  		bool Validate(int operands[]);
	public:
        InstSense();
        ~InstSense();
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstSense(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstSense NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};
/** \brief A class for the Flip instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. Generates a random number from 0 to p and sets
* a zero-state if the number is 0 and a nonzero-state if the number is not 0
*/
class InstFlip:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the upper limit p
* for the random generator, arr[1] is the zero-state and arr[2] is the nonzero-state
*/
        int arr[3];
/** \brief The state for the bug if the random number is 0
*/
		int zeroState;
/** \brief The state for the bug if the random number is not 0
*/
		int nonzeroState;
/** \brief Random generator
*
* This function implements a preudo-random generator which produces numbers from 0 to p, inclusive
* \return The pseudo-random number produced
*/
		unsigned long int Random();   
/** 
* \brief The upper limit for the random generator
*/
        unsigned long int p;
/** 
* \brief The seed for the random generator
*/
		static unsigned long int seed;
 		bool Validate(int operands[]);

	public:
 
		InstFlip();
        ~InstFlip();
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
        InstFlip(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstFlip NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif

};
/** \brief A class for the Move instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. It tries to move the bug forward, and sets
* success state if it suceeded and failure state if it could not move the bug
*/
class InstMove:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the success state
* and arr[1] is the failure state
*/
        int arr[2];

/** \brief The success state for the bug
*/
		int successState;
/** \brief The failure state for the bug
*/
		int failureState;
 		bool Validate(int operands[]);
	public:
        InstMove();
        ~InstMove();   
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstMove(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstMove NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};
/** \brief A class for the Pickup instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. If the cell has no food or the bug already has
* food, it sets failure state. Otherwise, it picks one food particle and sets success state
*/
class InstPickup:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the success state
* and arr[1] is the failure state
*/
        int arr[2];
/** \brief The success state for the bug
*/
		int successState;
/** \brief The failure state for the bug
*/
		int failureState;
 		bool Validate(int operands[]);
	public:
        InstPickup();
        ~InstPickup();
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstPickup(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstPickup NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};



/** \brief A class for the Drop instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. Drop drops the food a bug has in the current cell
* or does nothing if the bug has no food, and afterwards sets next state
*/
class InstDrop:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the next state
*/      
        int arr[1];
/** \brief The next state for the bug
*/
		int nextState;
 		bool Validate(int operands[]);
	public:
        InstDrop(); 
        ~InstDrop();   
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstDrop(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstDrop NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};
/** \brief A class for the Direction instruction. Inherits all the attributes from Instruction class
*
* It has overloaded Validate, Execute and printDebug, and inherited bool valid from Instruction class
* It has distinct constructors and additional attributes. If the bug is already facing the specified direction
* it sets success state, else it sets failure state
*/
class InstDirection:public Instruction
{
	private:
/**
* It holds the parameters of the instruction in as integer array for convinience. arr[0] is the direction,
* arr[1] is the success state and arr[2] is the failure state
*/
        int arr[3];
/** \brief The success state for the bug
*/
		int successState;
/** \brief The failure state for the bug
*/
		int failureState;
		int direction;
 		bool Validate(int operands[]);
	public:
        InstDirection(); 
        ~InstDirection();   
/** \brief The parametrized constuctor
*
*  It takes its parameters in an integer array, parses them and sets the attribute values accordingly
* \param The integer array of operands
* \param The maximum number of states, needed to error-check the input
*/
		InstDirection(int operands[],int MaxStates);
		int Execute(Bug& bug);
/** \brief A constructor that creates a duplicate of an instruction
*
*  This is a kind of copy constructor, creating a copy of the argument instruction
* \param The maximum number of states only, it takes the other parameters from the instruction itself
*/	
		InstDirection NewMe(int MaxStates);
#ifdef DEBUG
        void printDebug();
#endif
};

}

#endif ///__INSTRUCTION_H
