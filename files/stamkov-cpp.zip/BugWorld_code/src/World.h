/** \file World.h
 * \brief Implementation of the header file for the world.
 *
 * This is the implementation of the world. It was last worked on by
 * Stojanco Stamkov and Julian F�rstenau (XP Phase 3)
 * Container for the network of cells. Stores the bugs. Initializes
 * the cells and the bugs.
 */


#ifndef __WORLD_H__
#define __WORLD_H__

#include <iostream>
#include <string>
#include <vector>
#include "../src/Bug.h"
#include "../src/Cell.h"

namespace BugSim {    
    
/**
* \brief BugIterator is a typedef to a standard STL iterator.
*
* BugIterator provides a forward iterator through the vector of Bugs.
* It is not used as an usual iterator, as our vector containing the Bugs is private.
* Instead World provides two methods that are to be used in order to utilize the BugIterator.
*/
    typedef std::vector<Bug>::iterator BugIterator;

/**
* \brief Class World. It instantiates the cells and bugs.
*
* The World class is supposed to parse the map file, create the Bug and Cell instances
* and create the interconnections between all of them.
*/
    class World
    {

        private:
/**
* \brief A cell pointer pointing to the top left cell in the world
*/  
            Cell *topleftCell; /// Pointer to the topleft Cell in our Cell network.
/**
* \brief The X (width) dimension of the world
*/  
            int dimX;           /// X dimension of the Cell network
/**
* \brief The Y (height) dimension of the world
*/  
            int dimY;           /// Y dimension of the Cell network
/**
* \brief The number of bugs in the world
*/  
            int numBugs;    /// Contains number of bugs created.
/**
* \brief An STL container vector for keeping the bugs
*/  
            std::vector<Bug> Bugs;
/** \brief Map-parsing method.
*
* This is the function that parses the specified map file, creates instances, interconnects them
* and thoroughly checks for errors and throws an exception as needed.
* \param string fileName The filename of the map file to be parsed
*/
            void ParseMapFile(std::string fileName);

        public:
/**
* \brief World empty constructor
*/   
            World();
/**
* \brief World destructor
*/   
            ~World();
/**
* \brief World copy constructor
*/   
            World(World& nworld);
/**
* \brief World constructor.
*
* Takes the file name, and calls ParseMapFile, which parses the map file, creates bugs and cells.
* \param string fileName: The path to the map file that is going to be parsed
*/     
            World(std::string fileName);
 /** \brief Gets an iterator to the beginning of the vector
 *
 * Returns an iterator pointing to the beginning of the vector containing the Bugs.
 * This is the method to be used when a new iterator is requested.
 * \return It returns an iterator to the beginning of the vector
 */
            BugIterator GetBugIteratorBegin();
 /** \brief Gets an iterator to the end of the vector
 *
 * This method should be used whenever a BugIterator is used to ensure that the boundaries of the vector are not crossed.
 * \return Returns an iterator pointing to the end of the vector containing the Bugs.
 */
            BugIterator GetBugIteratorEnd();
/**
*\brief Prints out the states of all the cells.
*
*Goes through all the cells, starting from topleftcell, and prints out
*their states as defined by the corresponding function in Cell.cpp.
* \return It returns the string with the states information
*/
            std::string GetStateOfTheWorld();
/**
*\brief Converts two ints to a string
*
*Gets two integers a and b and creates a string (a,b). The numbers must be 3 digits each.
* \param int a: The first integer
* \param int b: The second integer
* \return It returns a string in the form (a,b)
*/
            std::string p2str(int a,int b);      ///takes two ints a and b and returns a string (a,b)
                                                    ///maximum input of 3 digits
    };

} ///namespace BugSim
#endif///__WORLD_H__
