/** \file Parser.cpp
 * \brief Implementation of the cpp file for the Parser class
 *
 * This is the implementation of the Parser class as declared in Parser.h.
 * It was last worked on by Stojanco Stamkov and Julian F�rstenau (XP Phase 3)
 */
 
/*****************************************************************************\
Parser.cpp

Revision history:
08.04.2006 - Stojanco Stamkov, Julian Fuerstenau - Modified the parsing procedure,
added documentation and testing. Also added additional helper methods for the parsing procedure
\*****************************************************************************/

#include <iostream>
#include <fstream>
#include <vector>
#include <memory>
#include <map>
#include "Bug.h"
#include "Cell.h"
#include "Instruction.h"
#include "Parser.h"

using namespace std;
using namespace BugSim;

Parser::Parser() {
     instTable.clear();
     }
Parser::~Parser() { 
    }
    
//Defined only for debugging and testing
//this method just prints the contents of the instruction table instTable
#ifdef DEBUG
  void Parser::print_table() {
      map<char, string>::iterator iter;
      
      for (iter = instTable.begin(); iter!=instTable.end(); iter++) {
          //prints the instruction code, and the instuction name
          cout << (unsigned int) iter->first << " " << iter->second << endl;
                }     
       }
#endif   

void Parser::RegisterInstruction(char InstCode, string InstName) {
     pair<char,string> tmp(InstCode,InstName);

// Checks if the instruction code is already in the table. Prints debug info only in the 
// debugging stage (when DEBUG is defined)
     map<char, string>::iterator iter  = instTable.find(InstCode);
     if (iter==instTable.end()) {
#ifdef DEBUG
     cout << "Instruction (" << (unsigned int) tmp.first <<"," <<tmp.second << ") not found. Inserting it now\n";
#endif                                
        instTable.insert(tmp);
        }
#ifdef DEBUG
      else cout << "Key (" << (unsigned int) tmp.first << ") already in table. Not inserted.\n";  
#endif
     }




vector<Instruction*> Parser::ParseInstructionFile(string filename) {
                     
    int i=0,j=0;
    unsigned int r=0;
//creates the stream that will be used for file reading
    fstream myfile;

//The vector in which all the instructions will be stored
    vector<Instruction*> ivect;
    
//converts the input string into character array for compatibility with read and write
    const char* fname=filename.c_str();
    
//open file for reading    
      myfile.open(fname, ifstream::in);
//if it can't be open, clear the variables and return
  if (!myfile.is_open())
  {
    cout << "Cannot open the file for reading.";
    cout << "Deleting the vector and returning an empty one\n";

    ivect.clear();
    return ivect;
  }



//number of bytes in the file
int numBytes;
//number of instructions in the file (numBytes/7)
int numInst;
  myfile.seekg(0, ios::end);
  numBytes = myfile.tellg();  //the size in bytes
cout << "numBytes is (number in bytes) " << numBytes << endl;
  //check file size
  if ((numBytes % 7) != 0)
  {
    cout << "Incomplete instruction file.\n";
    cout << "Deleting the vector and returning an empty one\n";

    ivect.clear();
    return ivect;
  }

      numInst=numBytes/7;
      //the number of states = the number of instructions
      int MaxStates=numInst;

    //To store one temporary instruction from the file stream
    char* inputchar=new char[7];
    //To store the character "binary" string, only with 0s or 1s
    char* bitstring=new char[56];
    //Temporary byte for conversion
    byte tByte;
    
  //Seek file again and parse each instruction
  myfile.seekg(0, ios::beg);
      
  //loops for each instruction, numInst times    
  for (i = 0; i < numInst; i++)
  {
    //Read an instruction
    myfile.read(inputchar, 7);
    
//    cout << "\n\nIn ASCII format:\n";
//    for (j=0; j<7; j++) {
//        cout << inputchar[j];
//        }
        
//        cout << endl << endl;

//converts each character from the 7-byte instruction into a character "binary" string
    for (j=0; j<7; j++) {
            tByte=convert(inputchar[j]);
        
            bitstring[j*8+0]=bit2char(tByte.b0);
            bitstring[j*8+1]=bit2char(tByte.b1);
            bitstring[j*8+2]=bit2char(tByte.b2);
            bitstring[j*8+3]=bit2char(tByte.b3);
            bitstring[j*8+4]=bit2char(tByte.b4);
            bitstring[j*8+5]=bit2char(tByte.b5);
            bitstring[j*8+6]=bit2char(tByte.b6);
            bitstring[j*8+7]=bit2char(tByte.b7);
            
            }
                   

//Here are the codes for the instruction from BinaryFormat.txt
//sense_code     ::= 0000,mark_code      ::= 0001,unmark_code    ::= 0010,pickup_code    ::= 0011
//drop_code      ::= 0100,turn_code      ::= 0101,move_code      ::= 0110,flip_code      ::= 0111
//direction_code ::= 1000,goto_code      ::= 1001

//Here are the instruction formats as defined in BinaryFormat.txt
//instruction[56] ::=
//          sense_code[4] sensedir[2] cond[4] zerofill[14] jumptrue[16] jumpfalse[16]
//	| mark_code[4] marker[3] zerofill[17] jumptrue[16] zerofill[16]
//	| unmark_code[4] marker[3] zerofill[17] jumptrue[16] zerofill[16]
//	| pickup_code[4] zerofill[20] jumptrue[16] jumpfalse[16]
//	| drop_code[4] zerofill[20] jumptrue[16] zerofill[16]
//	| turn_code[4] lr[1] zerofill[19] jumptrue[16] zerofill[16]
//	| move_code[4] zerofill[20] jumptrue[16] jumpfalse[16]
//	| flip_code[4] number[16] zerofill[4] jumptrue[16] jumpfalse[16]
//	| direction_code[4] dir[3] zerofill[17] jumptrue[16] jumpfalse[16]
//        | goto_code[4] zerofill[20] jumptrue[16] zerofill[16]

//Here, the parsing of the temp. instruction starts
//first, the instruction code is obtained (as an int) from the first 4 bits
        int inscode=bit2int(bitstring,0,3);
        
//an integer array in which the decoded instuction parametes will be stored
//used to call the specific Instruction constructor afterwards
        int operands[4];
        
//according to the instruction code, the specific parsing for each instruction type begins here
//look at the extract from BinaryFormat.txt above for the format details
//Also, many error checkings are done here. If an error occurs, the variables are cleared
//from memory and the procedure returns the cleared values
        switch (inscode) {
               //InstSense code
               case 0:
                    //if the instruction is not 0 in the specified regions
                    if ( !(checkzero(bitstring,10,23)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstSense\n";
                    cout << "Not all zero in specified regions" << endl;
                    cout << "Deleting the vector and returning an empty one\n";
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
                    //the sensting direction, will be stored arr[0]
                    int sdir;
                    sdir=bit2int(bitstring,4,5);
                    //the direction codes are DIFFERENTLY specified in the Instruction file
                    //and in the Parser file. Thus, the appropriate conversion is carried out here
                    switch (sdir) {
                           case 0:
                                 operands[0]=0; break; //means here
                           case 1:
                                 operands[0]=3; break; //means ahead, set to 3 to comply with instr. definition
                           case 2:
                                 operands[0]=1; break; //means leftahead
                           case 3:
                                 operands[0]=2; break; //means rightahead
                           default:
                                   cout << "Error in instruction number " << i << endl;
                                   cout << "Instruction type: InstSense\n";
                                   cout << "Wrong sense direction" << endl;
                                    cout << "Deleting the vector and returning an empty one\n";
                                      for (r=0; r<ivect.size(); r++) {
                                          delete ivect[r];
                                          }
                                    ivect.clear();
                                    return ivect;                                 
                                 }
                    //the success and failure states are written to the operands here
                    operands[1]=bit2int(bitstring, 24,39); //success state
                    operands[2]=bit2int(bitstring, 40,55); //fail state
                    
                    //checking for correct states
                    if ((operands[1]>= MaxStates) || (operands[2]>= MaxStates) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstSense\n";
                    cout << "Instruction target out of bounds" << endl;
                    cout << "Deleting the vector and returning an empty one\n";
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }  
                    
                    //getting the condition code. Also look at BinaryFormat.txt for details
                    int cond;
                    cond=bit2int(bitstring, 6,9);      
                    
                    switch (cond) {
                           case 0: operands[3]=6; break;
                           case 1: operands[3]=7; break;
                           case 2: operands[3]=8; break;
                           case 3: operands[3]=9; break;
                           case 4: operands[3]=10; break;
                           case 5: operands[3]=11; break;
                           case 6: operands[3]=0; break;
                           case 7: operands[3]=1; break;
                           case 8: operands[3]=2; break;
                           case 9: operands[3]=3; break;
                           case 10: operands[3]=4; break;
                           case 11: operands[3]=5; break;
                           case 12: operands[3]=12; break;
                           case 13: operands[3]=13; break;
                           case 14: operands[3]=14; break;
                           default:
                                   cout << "Error in instruction number " << i << endl;
                                   cout << "Instruction type: InstSense\n";
                                   cout << "Wrong condition" << endl;
                                    cout << "Deleting the vector and returning an empty one\n";
                                      for (r=0; r<ivect.size(); r++) {
                                          delete ivect[r];
                                          }
                                    ivect.clear();
                                    return ivect;                                  

                           }
                    
                    //finally, the Instruction is constructed and pushed back in the instruction vector ivect
                    ivect.push_back(new InstSense(operands, MaxStates));
                    break;
                    

               //InstMark code            
               case 1:
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,7,23)) || !(checkzero(bitstring,40,55)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstMark\n";
                    cout << "Not all zero in specified regions" << endl;
                    cout << "Deleting the vector and returning an empty one\n";
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[2];
                    operands[0]=bit2int(bitstring, 4,6);
                    operands[1]=bit2int(bitstring, 24,39);
                    
                    if (operands[0]>5) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstMark\n";
                    cout << "Wrong marker code" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }                                       
                    
                    if (operands[1]>= MaxStates) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstMark\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    } 
                    
                    ivect.push_back(new InstMark(operands, MaxStates));
                    break;
                    
                    
               case 2:
                    //InstUnmark code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,7,23)) || !(checkzero(bitstring,40,55)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstUnmark\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[2];
                    operands[0]=bit2int(bitstring, 4,6);
                    operands[1]=bit2int(bitstring, 24,39);
                    
                    if (operands[0]>5) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstUnmark\n";
                    cout << "Wrong marker code" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }                                       
                    
                    if (operands[1]>= MaxStates) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstUnmark\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    } 
                    
                    ivect.push_back(new InstUnmark(operands, MaxStates));
                    
                    break;
                    

               case 3:
                    //InstPickup code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,4,23)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstPickup\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[2];
                    operands[0]=bit2int(bitstring, 24,39);
                    operands[1]=bit2int(bitstring, 40,55);
 
                    if ((operands[0]>= MaxStates) || (operands[1]>= MaxStates) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstPickup\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }  
                    
                    ivect.push_back(new InstPickup(operands, MaxStates));
                    
                    break;
                    

               case 4:
                    //InstDrop code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,4,23)) || !(checkzero(bitstring,40,55)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstDrop\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[1];
                    operands[0]=bit2int(bitstring, 24,39);
  
                    if (operands[0]>= MaxStates) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstDrop\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }   
                    
                    ivect.push_back(new InstDrop(operands, MaxStates));
                    
                    break;
                    

               case 5:
                    //InstTurn code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,5,23)) || !(checkzero(bitstring,40,55)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstTurn\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[2];
                    operands[0]=bit2int(bitstring, 4,4);
                    operands[1]=bit2int(bitstring, 24,39);

                    if (operands[1]>= MaxStates) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstTurn\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    } 

                    ivect.push_back(new InstTurn(operands, MaxStates));
                    
                    break;
                    
                    

               case 6:
                    //InstMove code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,4,23)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstMove\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[2];
                    operands[0]=bit2int(bitstring, 24,39);
                    operands[1]=bit2int(bitstring, 40,55);
                    
                    if ( (operands[1]>= MaxStates) || (operands[2]>= MaxStates) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstMove\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    } 
                    
                    ivect.push_back(new InstMove(operands, MaxStates));
                    
                    break;   
                                     

               case 7:
                    //InstFlip code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,20,23)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstFlip\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
                    
//                    int operands[3];
                    operands[0]=bit2int(bitstring, 4,19);
                    operands[1]=bit2int(bitstring, 24,39);
                    operands[2]=bit2int(bitstring, 40,55);
                    
                    if ( (operands[1]>= MaxStates) || (operands[2]>= MaxStates) ) {
                            cout << "Error in instruction number " << i << endl;
                            cout << "Instruction type: InstFlip\n";
                            cout << "Instruction target out of bounds" << endl;
                              for (r=0; r<ivect.size(); r++) {
                                  delete ivect[r];
                                  }
                            ivect.clear();
                            return ivect;
                         }   
                                           
                    ivect.push_back(new InstFlip(operands, MaxStates));
                    
                    break;  
                    

               case 8:
                    //InstDirection code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,7,23)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstDirection\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
                    
//                    int operands[3];
                    operands[0]=bit2int(bitstring, 4,6);
                    operands[1]=bit2int(bitstring, 24,39);
                    operands[2]=bit2int(bitstring, 40,55);
                    
                    if ( operands[0]>5 ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstDirection\n";
                    cout << "Wrong direction" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }

                    if ( (operands[1]>= MaxStates) || (operands[2]>= MaxStates) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstDirection\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }  
                                                          
                    ivect.push_back(new InstDirection(operands, MaxStates));
                    
                    break;  
                    

               case 9:
                    //InstGoTo code
                    //the same comments as in InstSense apply
                    if ( !(checkzero(bitstring,4,23)) || !(checkzero(bitstring,40,55)) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstGoTo\n";
                    cout << "Not all zero in specified regions" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }
//                    int operands[1];
                    operands[0]=bit2int(bitstring, 24,39);
 
                    if ((operands[0]>= MaxStates) ) {
                    cout << "Error in instruction number " << i << endl;
                    cout << "Instruction type: InstGoTo\n";
                    cout << "Instruction target out of bounds" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;
                    }  
                    
                    ivect.push_back(new InstGoTo(operands, MaxStates));
                    
                    break;
                    
               default:
                   //if the instruction code doesn't exist
                   cout << "Error in instruction number " << i << endl;
                   cout << "No such instruction" << endl;
                      for (r=0; r<ivect.size(); r++) {
                          delete ivect[r];
                          }
                    ivect.clear();
                    return ivect;

        }
  
    }





  myfile.close(); //close the file
            
    return ivect;
}







//converts a char into its binary code
byte Parser::convert(char a) {
  byte *A;
  A = ( byte *)&a;
//it can be printed as:
//  cout << A->b0 << A->b1 << A->b2 << A->b3 << A->b4 << A->b5 << A->b6 << A->b7;
  return *A; 
  }

//Converts a single bit to the coresponding char
char Parser::bit2char(unsigned a) {
     if (a==0) return '0';
     else return '1';
     }

//Converts a binary string to decimal int. a and b are the starting and ending points in the array
int Parser::bit2int(char* arr, int a, int b) {
    int i=0;
    int res=0;
    for (i=b; i>=a; i--) {
        //if the bit is 1, add the value to the sum. Standard binary to decimal conversion
        if (arr[i]=='1')
           res+=(1<<(b-i));   //1 is bitwise shifted, means 2^(b-i-1)
        
        }
    return res;
}
    
//Checks the binary string if it is all 0s. a and b are the starting and ending points in the array
bool Parser::checkzero(char* arr, int a, int b) {
     int i;
     for (i=a; i<=b; i++) {
         if (arr[i]=='1') return false;
         }
     return true;
     }





//Globally defining the parser, so that it can be used in all the testing modules
//as specified in the specifications document
Parser* TheParser = new Parser();
