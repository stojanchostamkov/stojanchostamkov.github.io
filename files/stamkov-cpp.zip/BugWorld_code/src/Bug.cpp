/** \file Bug.cpp 
 * \brief Implementation of the cpp file for the bug.
 *
 * This is the implementation of the bug as defined in bug.h.
 * It was last worked on by Stojanco Stamkov and Julian Fuerstenau (XP Phase 3)
 */

#include <iostream>

#include "Bug.h"
#include "Cell.h"

using namespace std;
using namespace BugSim;

    Bug::Bug(Color icolor, Cell *icell) //: color(color), cell(cell)
    {
        
        /** Initial values for these attributes */
        color=icolor;
        cell=icell;
        direction = 0;
        state = 0;
        resting = 0;
        hasFood = false;
        isDead = false;
        cell->SetBug(this);
    }


    Color Bug::OtherColor(Color color) const
    {
        if(color == Black)
            return Red;
        else
            return Black;
    }


    Color Bug::GetColor() const
    {
        return color;
    }


    int Bug::GetState() const
    {
        return state;
    }


    void Bug::SetState(int newState)
    {
        state = newState;
    }


    bool Bug::HasFood() const
    {
        return hasFood;
    }


    bool Bug::PickupFood()
    {
        if(hasFood == false) {
            if(cell->GetFood() > 0)
            {
				cell->IncrementFood(-1); ///We can pick a maximum of 1 unit

                hasFood = true;          /// set to true indicating that the bug is now carrying food
                return true;
            }
            else return false;
        }
        else
            return false;
    }


    bool Bug::DropFood()
    {
        if(hasFood) {
            cell->IncrementFood(1); /* We can carry a maximum of 1 unit*/
            hasFood = false;            /* set to false indicating that the bug is now not carrying any food*/
            return true;
        }
        else
            return false;
    }


    int Bug::GetResting() const
    {
        return resting;
    }



    void Bug::IncrementResting(int rest)
    {
        resting += rest;
    }


    int Bug::GetDirection() const
    {
        return direction;
    }


	bool Bug::IsDead() const
	{
		return isDead;
	}



	void Bug::Turn(int ndir)  ///ndir = 0 is left, ndir = 1 is right
    {
        switch (ndir)
		{
			case 0:                     ///left
				direction = (direction+5)%6; break;

			default:                    ///right
			    direction = (direction+1)%6; break;

		}
    }


    bool Bug::Move()
    {
    Cell* pnewcell;
    pnewcell = cell->AdjacentCell(direction);

    if(pnewcell == NULL) return false;
    	else if(pnewcell->IsObstructed() || pnewcell->IsOccupied()) return false;
	     	else {
		    	cell->SetBug(NULL);
	     		cell = pnewcell;
		    	pnewcell->SetBug(this);
		    	return true;
		    }
	}


    Color Bug::WhosBase(int ndir)
    {

        switch (ndir) {
               case 0:                     ///here
                    return cell->WhosBase(); break;
               case 1:                    ///left-ahead
                    if ((cell->AdjacentCell((direction+5)%6))==NULL) return NoColor;
                    else
                    return cell->AdjacentCell((direction+5)%6)->WhosBase(); break;
               case 2:
                    if ((cell->AdjacentCell((direction+1)%6))==NULL) return NoColor;
                    else                   ///right-ahead
                    return cell->AdjacentCell((direction+1)%6)->WhosBase(); break;
               default:                    ///ahead
                    if ((cell->AdjacentCell(direction))==NULL) return NoColor;
                    else
                    return cell->AdjacentCell(direction)->WhosBase();


            }
    }


    bool Bug::IsObstructed(int ndir) const
    {
    Cell* pnewcell;
    int mydirection;

    switch(ndir){
                     case 0 : return false;break;

                     case 1 : mydirection = (direction+5)%6;                ///bug must sense a cell in a direction left to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
                              if(pnewcell==NULL) return true;
				              else return pnewcell->IsObstructed();break;

                     case 2 : mydirection = (direction+1)%6;               ///bug must sense a cell in a direction right to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
                              if(pnewcell==NULL) return true;
				              else return pnewcell->IsObstructed();break;

                     default: pnewcell = cell->AdjacentCell(direction);
                              if(pnewcell==NULL) return true;
                              else return pnewcell->IsObstructed();break;
                    }

    }



    bool Bug::IsBase(int ndir) const
    {
	Cell* pnewcell;
	int mydirection;

	switch(ndir){
	                 case 0 :                     ///here
							       return cell->IsBase(); break;
	                 case 1 : mydirection = (direction+5)%6;                ///bug must sense a cell in a direction left to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target";
				              else return pnewcell->IsBase();break;

	                 case 2 : mydirection = (direction+1)%6;               ///bug must sense a cell in a direction right to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target"<<endl;
				              else return pnewcell->IsBase();break;

	                 default: pnewcell = cell->AdjacentCell(direction);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target"<<endl;
	                          else return pnewcell->IsBase();break;
	                }

	}



    int Bug::GetFoodInCell(int ndir) const
    {

	Cell* pnewcell;
	int mydirection;

	switch(ndir){
	                 case 0:                     ///here
					      	return cell->GetFood(); break;
	                 case 1 : mydirection = (direction+5)%6;                ///bug must sense a cell in a direction left to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target"<<endl;
				              else return pnewcell->GetFood();break;

	                 case 2 : mydirection = (direction+1)%6;               ///bug must sense a cell in a direction right to the current direction
	                          pnewcell = cell->AdjacentCell(mydirection);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target"<<endl;
				              else return pnewcell->GetFood();break;

	                 default: pnewcell = cell->AdjacentCell(direction);
	                          if(pnewcell==NULL)
	                          cerr << "No cell in target"<<endl;
	                          else return pnewcell->GetFood();break;
	                }

	}



    bool Bug::IsOccupied(int ndir) const
    {
    Cell* pnewcell;
    int mydirection;
    switch (ndir) {
                 case 0 : return true;break;

                 case 1 : mydirection = (direction+5)%6;
	                           pnewcell = cell->AdjacentCell(mydirection);
                                  if(pnewcell==NULL)
                                  cerr << "No cell in target"<<endl;
				         else return pnewcell->IsOccupied();break;

                 case 2 : mydirection = (direction+1)%6;
	                            pnewcell = cell->AdjacentCell(mydirection);
                                   if(pnewcell==NULL)
                                   cerr << "No cell in target"<<endl;
				           else return pnewcell->IsOccupied();break;

                 default:
                          pnewcell = cell->AdjacentCell(direction);
                          if(pnewcell==NULL)
						  cerr << "No cell in target"<<endl;
						  else return pnewcell->IsOccupied();break;
                }
    }

    Color Bug::GetBugColorInCell(int ndir) const
    {
        switch (ndir) {
               case 0:                     ///here
                    return GetColor(); break;
               case 1:                    ///left-ahead
                    if ((cell->AdjacentCell((direction+5)%6))==NULL)
					cerr << "No cell in target"<<endl;
                    else if (((cell->AdjacentCell((direction+5)%6))->GetBug())==NULL) return NoColor;
                    else
                    return ((cell->AdjacentCell((direction+5)%6))->GetBug())->GetColor(); break;
               case 2:
                    if ((cell->AdjacentCell((direction+1)%6))==NULL)
					cerr << "No cell in target"<<endl;
                    else if (((cell->AdjacentCell((direction+1)%6))->GetBug())==NULL) return NoColor;
                    else
                    return ((cell->AdjacentCell((direction+1)%6))->GetBug())->GetColor(); break;
               default:                    ///ahead
                    if ((cell->AdjacentCell(direction))==NULL)
					cerr << "No cell in target"<<endl;
                    else if (((cell->AdjacentCell(direction))->GetBug())==NULL) return NoColor;
                    else
                    return ((cell->AdjacentCell(direction))->GetBug())->GetColor(); break;


            }
    }


    bool Bug::BugHasFoodInCell(int ndir) const

	{
	    switch (ndir) {
	           case 0:                     ///here
	                return HasFood(); break;
	           case 1:                    ///left-ahead
	                if ((cell->AdjacentCell((direction+5)%6))==NULL)
					cerr << "No cell in target"<<endl;
	                else if (((cell->AdjacentCell((direction+5)%6))->GetBug())==NULL) return false;
	                else
	                return ((cell->AdjacentCell((direction+5)%6))->GetBug())->HasFood(); break;
	           case 2:				  ///right-ahead
	                if ((cell->AdjacentCell((direction+1)%6))==NULL)
					cerr << "No cell in target"<<endl;
	                else if (((cell->AdjacentCell((direction+1)%6))->GetBug())==NULL) return false;
	                else
	                return ((cell->AdjacentCell((direction+1)%6))->GetBug())->HasFood(); break;
	           default:                    ///ahead
	                if ((cell->AdjacentCell(direction))==NULL)
					cerr << "No cell in target"<<endl;
	                else if (((cell->AdjacentCell(direction))->GetBug())==NULL) return false;
	                else
	                return ((cell->AdjacentCell(direction))->GetBug())->HasFood(); break;


	        }
	}


    bool Bug::GetMarker(Color color, int marker, int ndir) const
    {
	Cell* pnewcell;
	int mydirection;
	switch (ndir) {
	             case 0 : return cell->GetMarker(color,marker);break;

	             case 1 : mydirection = (direction+5)%6;
	                           pnewcell = cell->AdjacentCell(mydirection);
	                              if(pnewcell==NULL)
	                              cerr << "No cell in target"<<endl;
				         else return pnewcell->GetMarker(color,marker);break;

	             case 2 : mydirection = (direction+1)%6;
	                            pnewcell = cell->AdjacentCell(mydirection);
	                               if(pnewcell==NULL)
	                               cerr << "No cell in target"<<endl;
				           else return pnewcell->GetMarker(color,marker);break;

	             default:
	                      pnewcell = cell->AdjacentCell(direction);
	                      if(pnewcell==NULL)
						  cerr << "No cell in target"<<endl;
						  else return pnewcell->GetMarker(color,marker);break;
	            }
	}





    bool Bug::IsMarked(Color color, int ndir) const

	{
	Cell* pnewcell;
	int mydirection;
	switch (ndir) {
	             case 0 : return cell->IsMarked(color);break;

	             case 1 : mydirection = (direction+5)%6;
	                           pnewcell = cell->AdjacentCell(mydirection);
	                              if(pnewcell==NULL)
	                              cerr << "No cell in target"<<endl;
				         else return pnewcell->IsMarked(color);break;

	             case 2 : mydirection = (direction+1)%6;
	                            pnewcell = cell->AdjacentCell(mydirection);
	                               if(pnewcell==NULL)
	                               cerr << "No cell in target"<<endl;
				           else return pnewcell->IsMarked(color);break;

	             default:
	                      pnewcell = cell->AdjacentCell(direction);
	                      if(pnewcell==NULL)
						  cerr << "No cell in target"<<endl;
						  else return pnewcell->IsMarked(color);break;
	            }
	}


    void Bug::SetMarker(bool value, int marker)
    {
        cell->SetMarker(color, marker, value);
    }


    void Bug::Die()
    {
        if(hasFood == true)
            DropFood();                 /// drop any food that is being carried
        cell->IncrementFood(3);   /// increment the food in the Cell, because a bug has just died
        cell->SetBug(NULL);   /// sets the cell where a bug has died to NULL to show that there are no bugs in it
        isDead = true;
    }
