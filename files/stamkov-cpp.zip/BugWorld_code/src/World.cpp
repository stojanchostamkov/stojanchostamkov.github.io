/** \file World.cpp
 * \brief Implementation of the cpp file for the world.
 *
 * This is the implementation of the world as defined in World.h.
 * It was last worked on by Stojanco Stamkov and Julian Fuerstenau (XP Phase 3)
 */

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include "World.h"
#include "Bug.h"
#include "Cell.h"

using namespace std;
using namespace BugSim;

World::World() {
    topleftCell=NULL;
    dimX=0;
    dimY=0;  
    numBugs=0;
    Bugs.clear();
    }
            
World::~World() { 
}

World::World(World& nworld) {
    topleftCell=nworld.topleftCell;
    dimX=nworld.dimX;
    dimY=nworld.dimY;
    numBugs=nworld.numBugs;
    Bugs=nworld.Bugs;
}


World::World(string fileName)
{
    numBugs=0;
	ParseMapFile(fileName); /// ParseMapFile does all the work for parsing and creating bugs and cells.
}


BugIterator World::GetBugIteratorBegin()
{
    vector<Bug>::iterator pos;     /// STL vector iterator
    pos = Bugs.begin();                      /// point it to the beginning of the vector
    return pos;
}


BugIterator World::GetBugIteratorEnd()
{
    vector<Bug>::iterator pos; /// STL vector iterator
    pos = Bugs.end();                     /// point it to the end of the vector
    return pos;
}

string World::p2str(int i,int j) {
    string res="";
    char buffi[3];
    char buffj[3];

//Storing the integers i and j in char arrays for appending to string state
//48 is the decimal ASCII code for '0'
    buffi[2]=48+(i%10);      
    buffi[1]=48+((i/10)%10);
    buffi[0]=48+(i/100);

    buffj[2]=48+(j%10);
    buffj[1]=48+((j/10)%10);
    buffj[0]=48+(j/100);
    res=res+"("+buffi+","+buffj+")";
    return res;
    
}

void World::ParseMapFile(string fileName)
{
    const char *file = fileName.c_str();    ///putting the contents of the string into a char * arra
    ifstream mapFile(file);                /// in order to create an input file stream
    int numBlack=0;                        //the number of red and black bugs/cells
    int numRed=0;
    
    /// Throw an exception if the file cannot be found or accessed
    if((mapFile.is_open() == false)|| (!mapFile.good())) {
        Bugs.clear();
        topleftCell=NULL; 
        throw string("IO Exception: Can't open file");

        }
       
    string line;
    int i;
    Cell **array;           /// Initially all the newly created Cells are stored here
    int indexX=0;       /// Index into the Cell matrix, corresponds to matrix row

    try {

        /// Read map dimensions
//        mapFile >> dimX;
//        mapFile >> dimY;
        char linech1[4];
        char linech2[4];
        mapFile >> linech1;
        mapFile >> linech2;

        dimX=atoi(linech1);          
        dimY=atoi(linech2);
        //check whether atoi was successful
        if ((dimX<=0)||(dimY<=0) || (dimX>200) || (dimY>200)) {
           Bugs.clear();
           topleftCell=NULL; 
           throw string("File parsing error: Invalid map dimensions (each should be from 1 to 200)");
           }
        
        array = new Cell* [dimX];
        for(i=0; i<dimX; i++)
            array[i] = new Cell[dimY];

        getline(mapFile, line); /// get the remaining newline character



        while(getline(mapFile, line))  {
                               
            line.erase(remove_if(line.begin(), line.end(),
            bind2nd(equal_to<char>(), ' ')), line.end());/// remove all whitespaces inside the string
            if ((line.size()!=dimX) || (indexX>=dimY)) {    //test for larger or smaller lines, and also for row number
               Bugs.clear();
               topleftCell=NULL; 
               for (int cnt=0; cnt<dimX; cnt++) {
                   delete[] array[cnt];
                   }
               delete[] array;
               if (line.size()!=dimX)  
                  throw string("File parsing error: Wrong/inconsistent number of columns specified.\nTry removing last newline");
               else
                  throw string("File parsing error: More rows than specified.\nTry removing last newline"); 
               }
            for(i=0; i<line.size(); i++) {

                /// Switch statement that checks every character inside each line
                switch(line[i]) {

                    /// Obstructed Cell
                    case '#':
                        array[i][indexX] = Cell(true, 0, false, NoColor);
                        break;

                    // Free Cell
                    case '.':
                        array[i][indexX] = Cell(false, 0, false, NoColor);
                        break;

                    /// Black base Cell
                    case '-':
                        array[i][indexX] = Cell(false, 0, true, Black);     /// create a new base cell
                        Bugs.push_back(Bug(Black, &array[i][indexX])); /// put the newly created bug in the array
                        array[i][indexX].SetBug(&(*Bugs.end()));             /// sets a pointer in the Cell to its Bug
                        numBugs++;  
                        numBlack++;                                                    /// new bug created, increment
                        break;

                    /// Red base Cell
                    case  '+':
                        array[i][indexX] = Cell(false, 0, true, Red);        /// create a new base cell
                        Bugs.push_back(Bug(Red, &array[i][indexX]));  /// put the newly created bug in the array
                        array[i][indexX].SetBug(&(*Bugs.end()));             /// sets a pointer in the Cell to its Bug
                        numBugs++;
                        numRed++;
                        break;

         //           Cases below create cells, that are neither base nor obstructed
//					and contain the corresponding units of food
//					
                    case '1' :
                        array[i][indexX] = Cell(false, 1, false, NoColor);
                        break;
                     case '2' :
                        array[i][indexX] = Cell(false, 2, false, NoColor);
                        break;
                     case '3' :
                        array[i][indexX] = Cell(false, 3, false, NoColor);
                        break;
                    case '4' :
                        array[i][indexX] = Cell(false, 4, false, NoColor);
                        break;
                     case '5' :
                        array[i][indexX] = Cell(false, 5, false, NoColor);
                        break;
                     case '6' :
                        array[i][indexX] = Cell(false, 6, false, NoColor);
                        break;
                    case '7' :
                        array[i][indexX] = Cell(false, 7, false, NoColor);
                        break;
                    case '8' :
                        array[i][indexX] = Cell(false, 8, false, NoColor);
                        break;
                    case '9' :
                        array[i][indexX] = Cell(false, 9, false, NoColor);
                        break;

                    default:
                        Bugs.clear();
                        topleftCell=NULL; 
                        for (int cnt=0; cnt<dimX; cnt++) {
                            delete[] array[cnt];
                            }
                        delete[] array;
                        throw string("File parsing error: Unknown character in postion"+p2str(i,indexX));
                        } //end of switch
            }

            indexX++;
        }
        
        //checking for the number of rows
        if (indexX<dimY) {
            Bugs.clear();
            topleftCell=NULL; 
            for (int cnt=0; cnt<dimX; cnt++) {
                delete[] array[cnt];
                }
            delete[] array;
            throw string("File parsing error: Wrong/inconsistent number of rows specified.\nTry removing last newline");
           }
        
        //checking the bugs
            if (numBlack!=numRed) {
        Bugs.clear();
        topleftCell=NULL; 
        for (int cnt=0; cnt<dimX; cnt++) {
            delete[] array[cnt];
            }
        delete[] array;
        throw string("File parsing error: Different number of red and black bugs");
       }       
    }
//    Catch and rethrow an IOException
//	if the map cannot be parsed
//	
    catch(exception &e)
    {
        Bugs.clear();
        for (int cnt=0; cnt<dimX; cnt++) {
            delete[] array[cnt];
            }
        delete[] array;
        topleftCell=NULL; 
        throw "IO Exception: Unknown";
    }

    topleftCell = &array[0][0];

//The nested for loops below
//create the network of Cells as specified by the specification
//using the matrix of Cells that was created earlier

    for(int j=0; j<dimY; j++)
        for(int i=0; i<dimX; i++) {
        Cell *adjArray[6];

        /// direction == 0
        if( (i+1) < dimX)
            adjArray[0] = &array[i+1][j];
        else
            adjArray[0] = NULL; /// Set this adjacent cell to a new obst

        /// direction == 1
       if ((j%2==0 || i < dimX-1 ) && (j < dimY-1) ) {
          if (j%2==0) adjArray[1] = &array[i][j+1];
             else adjArray[1] = &array[i+1][j+1];
                     }
	   else
            adjArray[1] = NULL;/// Set this adjacent cell to a new obstr

        /// direction == 2
       if ((j%2==1 || i > 0 ) && (j < dimY-1) ) {
          if (j%2==1) adjArray[2] = &array[i][j+1];
             else adjArray[2] = &array[i-1][j+1];
                     }
       	else
            adjArray[2] = NULL;/// Set this adjacent cell to a new obstr

        ///direction == 3
	    if(i>0)
            adjArray[3] = &array[i-1][j];
          else
            adjArray[3] =  NULL;/// Set this adjacent cell to a new obstr


	    /// direction == 4
       if ((j%2==1 || i > 0 ) && (j >0 )) {
          if (j%2==1) adjArray[4] = &array[i][j-1];
             else adjArray[4] = &array[i-1][j-1];
                     }
       	else
            adjArray[4] = NULL;/// Set this adjacent cell to a new obstr

        /// direction == 5
       if ((j%2==0 || i < dimX-1 ) && (j >0) ) {
          if (j%2==0) adjArray[5] = &array[i][j-1];
             else adjArray[5] = &array[i+1][j-1];
                     }
	   else
            adjArray[5] = NULL;/// Set this adjacent cell to a new obstr

	///set adjacent cells
	    array[i][j].SetAdjCells(0, adjArray[0]);
	    array[i][j].SetAdjCells(1, adjArray[1]);
	    array[i][j].SetAdjCells(2, adjArray[2]);
	    array[i][j].SetAdjCells(3, adjArray[3]);
	    array[i][j].SetAdjCells(4, adjArray[4]);
	    array[i][j].SetAdjCells(5, adjArray[5]);
	}



}


string World::GetStateOfTheWorld()	//const
{
    if (Bugs.empty()) return "This is an empty world\n";
	string state = "";
	string temps;

	Cell* rowstartCell = topleftCell; ///first row starts with topleftcell
	Cell* printCell;

	for (int j=0;j<dimY;j++)	   ///go through all the rows
	{

		printCell = rowstartCell;  ///the first cell to be printed for each row is always the "rowstartcell", the first cell in the row
//		state = state + printCell->GetState(); ///the old string is concatenated with GetState from the current cell.
		for	(int i=0;i<dimX;i++)   		///going through the cells of the row
		{

			state = state+"ID:"+p2str(i,j)+" "+ printCell->GetState();	 ///this cell's info is aded to the state-string
			printCell = printCell->AdjacentCell(0);	 ///the cell right of the old one is f course its AdjacentCell(0)

		}
		if (j%2 == 0)
			rowstartCell = rowstartCell->AdjacentCell(1); ///determine the cell at the beginning of the next row
		else
			rowstartCell = rowstartCell->AdjacentCell(2);

	}

	return state;
}
