/** \file Cell.h 
  *\brief Implementation of the header file for the cell.
  *
  *This is the implementation of the cell. It was last worked on by
  *Stojanco Stamkov and Julian F�rstenau (XP Phase 3)
  *This is header file for the Cell class. The cell class implements the core of
  *the map and spans the grid networkby referencing the six surrounding units. Its
  *attributes capture the current state of the cell to which it provides an
  *interface. Further methods codify aspects of the world.
  *Comments:
  *Before the beginning of every method there are some comments:
  * the comments "Description" describe the usage of the method, while the
  *	"Testing" describes the exceptions beeing thrown by the method.
  * The functional testing of the method and of the class will be described
  * later
  */

#ifndef __CELL_H__
#define __CELL_H__
#include <string>
#include <exception>

namespace BugSim {
///forward declaration so that we avoid circular inclusions
#pragma pointers_to_members(full_generality)
#ifndef __BUG_COLOR__
#define __BUG_COLOR__
typedef enum {Red, Black, NoColor} Color;
#endif///__BUG_COLOR__

class Bug;

/**
* \brief The class representing a cell in the world
*
* This is the class which provides the methods for manipulating the cell's attributes
* in order to succesfully simulate the environment as specified in the specification files
*/ 
class Cell
{
private:
    /**
    * a value from 0 to 63. it stands for the binary representation of the markers
    */
	int blackMarker; 
    /**
    * same as above, just that it is done for the markers of the differnt color
    */
	int redMarker; 
    /**
    * the amount of food stored in the cell
    */
	int food ;    
    /**
    * reference to the bug that is stading in the cell. NULL if the cell contains no bug
    */
	Bug *bug ;
    /**
    * specifies if the cell is a base
    */
	bool isBase ; 
    /**
    * specifies whose base the cell is
    */
	Color whosBase ;    
    /**
    * specifies if the cell is obstructed
    */
	bool isObstructed ; 
#ifndef DEBUG
    /**
    * an array of references to the adjacent cells
    */
	Cell* adjCells[6] ; 
#endif
    /**
    * minimum number of bugs necessary to kill a bug
    */
	int tresholdKill; 
    /**
    * \brief how much food a bug generates when it dies
    */
	int foodForBug;  



public:
#ifdef DEBUG         

	   Cell* adjCells[6]; ///used for debugging only. If DEBUG is not defined, it proceeds normally,
                          /// as a private attribute
#endif
/** \brief Empty constructor for the cell
*
* Description:It assigns the default attributes of the
*             cell: isObstructed, food, isBase and whosBase to their default values
*/
    Cell(); 
/** \brief Constructor for the cell
*
* Description:It assigns the basic attributes of the
*             cell: isObstructed, food, isBase and whosBase.
*             The array adjCells[] is set to NULL for all values, at the time of
*             initialization (call of constructor). These will be set from the
*             higher instance using a setter method:
*                    void SetAdjCells(int direction, Cell *c);
*Testing: used color is not defined, food is negative
*/
	Cell(bool, int, bool, Color); 
/** \brief The setter SetMarker sets the value of the marker indicated by
*	the parameter marker, for the given color, to the value given by the parameter
*	value.
*
*   Marker encoding: The markers are all stored in one integer. The binary
*   representation is used. Ex: 100 100 means that marker 5 and 2 are activated.
*   The leftmost marker is the 5th marker, and the rightmost is the 0th marker.
*   The encoding and decoding process is done by bit shifting.
*
*   Tests: Different input for the marker (<0 and >5) and color.
*
*/
	void SetMarker (Color, int ,bool);
/**  \brief The getter GetMarker returns the value of the marker indicated
*	by the parameter marker, for the given color.
*
*   Marker encoding: same as for the setter method.
*
*   Tests: Different input for the marker (<0 and >5) and color.
*
*/
	bool GetMarker (Color, int);
/**
*Description: Returns whether the current cell is marked by the given color
*Testing: color given is not defined,
*/
	bool IsMarked(Color);
/** \brief increments food-value
*
*Description: increments the current value of the food storred in the current
*cell with the amount specified as a parrameter. The prameter can also have
*negative values since we may want to decrease the amount of food stored by a
*cell after a bug has piked up food.
*
*Testing: it has to be somehow verified if value for food after the execution of
*         the function is still positive.
*/
	void IncrementFood(int);
/**
*Description: Getter method. Returns the amount of food currently stored in the
*             cell.
*Testing: what it outputs
*/
	int GetFood();
/**
*Description: references the bug to the current cell
*Testing: check action
*/
	void SetBug(Bug*);
/**
*Description: Returns a reference to the bug in the current cell.
*Testing: check returned data
*/
	Bug* GetBug();
/**
*Description: Returns whether the current cell is obstructed.
*Testing: none
*/
	bool IsObstructed();
/**
*Description: Returns whether the current cell is occupied.
*Testing: none
*/
	bool IsOccupied();
/**
*Description: Returns whether the current cell is a base.
*Testing: none
*/
	bool IsFree();
/**
*Description: Returns whether the current cell is free. (there is no bug in it)
*Testing: none
*/
	bool IsBase();
/**
*Description: Returns the color of the species of bugs which owns the cell.
*Testing: need to make sure that the method is not called for a cell that is not
*         a base
*/
	Color WhosBase();
/** \brief	 Returns a reference to the adjacent cell in the given direction.
*
*Description: Returns a reference to the adjacent cell in the given direction.
*Direction is an integer from 0 to 5 (as specified in the problem description)
*Testing: exception raised if direction is not an integer between 0 and 5
*/
	Cell* AdjacentCell(int);
/**
* \brief Description: Moves the bug in the current cell in the given direction.
*
*Testing: test if direction is valid (number between 0 and 5)
*         test if the cell the bug attempts to move to:
*              - exists
*              - is free
*              - is not obstructed
*/
	Cell* MoveBug(int);
/**
* \brief Returns the state of the cell encoded in a string.
*
*Description: Returns the state of the cell encoded in a string. This means that
*the current attributes of the cell are returned to a string for logging purposes
*Testing:
*/
	std::string GetState();
/**
*\brief Checks if a bug has to be killed
*
*Description: Checks whether the bug in current cell should get killed and if it should it
*kills it (does every necessary changes to the enviroment)
*Testing: none;
*/
    void CheckKill();
/**
* \brief	Sets the reference to adjacent cells
*
*Description: Sets the reference of the adjacent cell in the given direction, to
*the one passed through the parameter ce. Direction is an integer from 0 to 5 (as
*specified in the problem description)
*Testing: exception raised if direction is not an integer between 0 and 5
*/
    void SetAdjCells(int, Cell*); 
};

} ///namespace BugSim

#endif///__CELL_H__
