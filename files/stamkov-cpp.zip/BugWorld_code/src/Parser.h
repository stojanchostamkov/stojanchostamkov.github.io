/** 
 * \file Parser.h
 * \brief The parser class is declared here
 *
 * This file contains the declaration of Parser class as defined in the specifications
 */
 
/*****************************************************************************\
Parser.h

Revision history:
08.04.2006 - Stojanco Stamkov, Julian Fuerstenau - Modified the parsing procedure,
added documentation and testing. Also added additional helper methods for the parsing procedure
\*****************************************************************************/

#ifndef __BIT_STRUCT
#define __BIT_STRUCT



namespace BugSim {
          
/**
* \brief struct bit_structi is a struct with 8 bits
*
* This will be used to store the bits of a char. We will use it to write/read the binary code for
* the parser. The index is inverted on purpose (from b7 to b0), since the struct is created in the reverse bit order of litle endian notation
*/          
struct bit_struct {
  unsigned b7:1;
  unsigned b6:1;
  unsigned b5:1;
  unsigned b4:1;
  unsigned b3:1;
  unsigned b2:1;
  unsigned b1:1;
  unsigned b0:1;
};
/**
* \brief a typedef for the bit_struct, will be refered to as byte
*/   
typedef bit_struct byte;
#endif //__BIT_STRUCT
 //namespace BugSim



#ifndef __PARSER_H__
#define __PARSER_H__


/**
* \brief The class responsible for parsing an instruction file
*
* The Parser class' main purpose is to read the binary-encoded instruction file (see BinaryFormat.txt for
* details about the format), and create an STL vector with the parsed instructions, keeping the order of
* the instructions. It also keeps an instruction table, to keep track of the registered/unregistered instructions
*/  
class Parser
{
private:
/**
* \brief The table which holds the instructions in the format <char, string>, meaninig <instruction code, instruction name>
*/  
  std::map <char, std::string> instTable;
/**
* \brief Converts a character into it's binary code, with type byte
* \param a : the character which needs to be converted to binary code
* \return A byte containing the code for the character
*/  
  byte convert(char a);
  
/**
* \brief Converts a single bit (type integer, 0 or 1) to the character 0 or 1, respectively
* \param a : the integer (0 or 1)
* \return The character 0 or 1
*/  
  char bit2char(unsigned a);

/**
* \brief Converts a character array to integer
*
* Converts the bit character array (only 0 or 1) from ara[a] to arr[b] inclusively, into
* an integer, using unsigned (direct) binary to decimal conversion
* \param arr : The array with the characters arr
* \param a: the starting arr index (arr[a])
* \param b: the ending arr index (arr[b])
* \return The decimal number in integer type
*/  
  int bit2int(char* arr, int a, int b);
    
/**
* \brief Checks the character array if it's 0 in the specified range
*
* Checks the binary string if it is all 0s from arr[a] to arr[b] inclusively.
* \param arr : The array with the characters arr
* \param a: the starting arr index (arr[a])
* \param b: the ending arr index (arr[b])
* \return true if arr is 0 in the specified range, false otherwise
*/  
  bool checkzero(char* arr, int a, int b);


public:
/**
* \brief The empty constructor
*/
  Parser();
/**
* \brief The destructor
*/
  ~Parser();
  
/**
* \brief Method for registering new instructions
*
* When a new instruction is encountered, it is registered into the instruction table instTable
* by this method
* \param InsCode, the code of the instruction stored as a char
* \param InstName, the instruction name stored as a string
*/  
  void RegisterInstruction(char InsCode, std::string InstName);
/**
* \brief The main file parsing method
*
* This is the method which reads a binary file, parses it, checks for parsing errors and
* creates an STL vector of type Instruction* for storing the created instructions. It uses the small additional privete
* methods documented above (convert, bit2char, bit2int, checkzero)
* \param A string with the path to the file to be parsed
* \return An STL Instruction* vector, in which the instructions are stored in the order in which they are parsed
*/  
  std::vector<Instruction*> ParseInstructionFile(std::string filename);


#ifdef DEBUG
/**
* \brief A debugging method for printing the instruction table
*
* This method prints to the screen the contents of the instuction table. The method is accessible
* only if the DEBUG macro is defined
*/ 
  void print_table();
#endif   
};





} //namespace BugSim

#endif//__PARSER_H__




