/** \file Cell.cpp
*\brief Implementation of the cpp file for the cell.
*
* This is the implementation of the bug as defined in cell.h.
* It was last worked on by Stojanco Stamkov and Julian F�rstenau (XP Phase 3)
*This file provides the implementations of all the methods described in the Cell
*header file. It follows the specifications provided in the Specifications.pdf
*file. The code follows the principles of defensive programming.
*It does various tests on the input and throws exceptions whenever something is
*wrong. The exceptions are caught in a separate code located in another file.
*Comments:
*Before the beginning of every method there are some comments:
* 	the comments "Description" describe the usage of the method, while the
*	"Testing" describes the exceptions beeing thrown by the method.
* 	The functional testing of the method and of the class will be described
*  	later
*Descriptions of the methods are provided in the Cell.h file.
*Usefull comments are provided whenever necessary.
*/



#include "Cell.h"
#include "Bug.h"
#include <string>
#include <sstream>
#include <iostream>

using namespace std;
using namespace BugSim;

/*************************************************************************/


Cell :: Cell ()
{
     blackMarker = 0; ///default for blackMarker
     redMarker = 0; ///default for redMarker
     food = 0; ///default for the amount of food stored in the cell
	 isObstructed = false;
	 isBase = false;
     bug = NULL ; ///default value for the pointer bug
	 for (int i = 0; i < 6; i++ ) adjCells[i] = NULL;
	 /// set the pointers to the adjacent cells to NULL.

}

Cell :: Cell (bool obstructed, int c_food, bool c_isBase, Color c_whosBase)
{
           int i;

           blackMarker = 0 ; ///a value from 0 to 63. it stands for the binary representation of the markers
	       redMarker = 0 ; /// same as above, just that it is done for the markers of the differnt color
	       bug = NULL ; ///reference to the bug that is stading in the cell. NULL if the cell contains no bug

           isObstructed = obstructed ; /// specifies if the cell is obstructed
           food = c_food ; /// set the number of food pieces
           isBase = c_isBase ; /// set isBase
           if (c_isBase) whosBase = c_whosBase ; ///if a base, set what base it is

           for ( i = 0; i < 6; i++ ) adjCells[i] = NULL;
           /// set the pointers to the adjacent cells to NULL.
}


bool Cell :: GetMarker (Color color, int marker)  ///Cel_GtMa_argMarker, Cel_GtMa_argColor)
{


    if (( color != Red ) && ( color != Black )) throw "Cel_GtMa_argColor";
    ///throws error for wrong color value

    if (( marker < 0 ) || (marker > 5 )) throw "Cel_GtMa_argMarker";
    ///throws error for wrong marker value

    if(color == Black)
    {
    	if(((blackMarker >> marker) & 1) == 1)
    		return true;
    	else
    		return false;
    }
    else
    {
    	if(((redMarker >> marker) & 1) == 1)
    		return true;
    	else
    		return false;
    }

}




void Cell :: SetMarker (Color color, int marker, bool value) ///Cel_StMa_argMarker, Cel_StMa_argColor)
{
    int result, tmp;  ///one return; result will hold the value of the markers
    bool col = 0;  ///boolean: red == 0 and black == 1 (default is red)

    if (( color != Red ) && ( color != Black )) throw "Cel_StMa_argColor";
    ///throws error for wrong color value

    if (( marker < 0 ) || (marker > 5 )) throw "Cel_StMa_argMarker";
    ///throws error for wrong marker value

    if (color == Red)
       { col = 0; result = redMarker;} ///sets col to red and loads the value of the redMarker into result
       else
            { col = 1; result = blackMarker;}///sets col to black and loads the value of the blackMarker into result

    tmp = (result >> marker) % 2; /// holds the value of the existing marker
    /// if the marker already has the intended value do not change it
    if (tmp != value)
       if (value) result = result + (value << marker);
          else result = result - ((!value) << marker);
          /* when we change the marker to ON i.e. 1, we add a value of 1 shifted
          *to the left by the given order of the marker, else we subtract 1 = (!0)
          *shifted to the left by the marker value
          */

    if (col) blackMarker = result; /// return result to the correct marker set
       else redMarker = result;
}






bool Cell :: IsMarked(Color color) ///Cel_IsMa_argColor)
{
     if (( color != Red ) && ( color != Black )) throw "Cel_IsMa_argColor";
    ///throws error for wrong color value
      if (color == Red)
        {
         if (redMarker !=0 ) return true ;
         else return false ;
         }
      else
      
             {
              if (blackMarker != 0) return true ;
              else return false ;
              }

}





void Cell :: IncrementFood(int howmuchfood) ///Cel_IncFood_negFood)
{
          int tmp = food + howmuchfood; /// hold the attempted value of food in the cell

          if (tmp < 0) throw "Cel_IncFood_negFood";
          /// throws exception if it is attempted to decrement more food than it exists in the cell
          else food = tmp; ///set food to the new value
}



int Cell::GetFood()
{
    return food ;
}


 void Cell::SetBug(Bug* b)
 {
      bug = b ;
 }




Bug* Cell::GetBug()
{
     return bug ;

}



bool Cell::IsObstructed()
{
     return isObstructed ;
}



bool Cell::IsOccupied()
{
     if (bug == NULL)
         return false ;
        else
            return true ;
}




bool Cell::IsBase()
{
     return isBase ;
}





bool Cell::IsFree()
{
     if (bug != NULL) return false ;
        else
             return true ;

}




Color Cell::WhosBase() //Cel_WhBa_notBase)
{
      if (isBase) return whosBase ;
         else throw "Cel_WhBa_notBase"; //throws error in case input not a Base
}




Cell* Cell::AdjacentCell(int direction) ///Cel_AjCe_argDirection)
{
    if (( direction < 0 ) || (direction > 5 )) throw "Cel_AjCe_argDirection";
    ///throws error for wrong direction value i.e <0 && >5
    else return adjCells[direction] ;
}





Cell* Cell::MoveBug( int direction ) ///Cel_MovBug_outofbound, Cel_MovBug_ObstCell, Cel_MovBug_OcupCell)
{
  if (adjCells[direction] = NULL) throw "Cel_MovBug_outofbound"; /// if there is no adj cell throw error
      else
       if (adjCells[direction]->IsObstructed()) throw "Cel_MovBug_ObstCell"; /// if the cell in the direction is obstructed, throw error
          else
              if (adjCells[direction]->IsOccupied()) throw "Cel_MovBug_OcupCell";
                 else
                         {
                          adjCells[direction]->SetBug(bug); ///putting the bug in the desired cell
                          bug = NULL; /// removing the bug from the current cell
                          return adjCells[direction];
                          }
}




void Cell::CheckKill()
{
if ( bug != NULL ) ///do not call the funtion if there is no bug in the cell
 {
     int i,enemy=0, additional=0;       /// i is the iterator; enemy is the number of enemy bugs surronding the current bug; additional is the food carried by the bug
     Bug *a_bug, *current_bug ; /// current_bug is the bug in the current cell; a_bug is a_bug in the adjacent cell
     Color a_color, current_color ; /// current_color is the color of the bug from the current cell; a_color is the color of the bug in an adjacent cell

     current_bug = bug;
     current_color = current_bug->GetColor();

     for ( i = 0 ; i <= 5 ; i++ ) /// for every adjacent cell
         if ( adjCells[i]->IsOccupied() == true )   ///check if it is occupied
           {
             a_bug = adjCells[i]->GetBug() ;  ///and if it is check if the bug is an enemy
             a_color = a_bug->GetColor() ;
             if (a_color != current_color )   ///and if it is increment the number of enemies
                enemy++ ;
           }

      if ( enemy >= tresholdKill ) /// check if the bug has to die
                 {
                      if (current_bug->HasFood() == true)  ///check if bug has food
                               additional = 1;
                      current_bug->Die() ;  ///sets the value of isDead to true (in the class bug)
                      bug = NULL;           ///removes the bug from the cell
                      food += foodForBug + additional;  ///turns it into food
                 }
  }
}




string Cell::GetState()
{
       string output = " cell ";
       string aux;
       ostringstream ss;
       Color color;
       if ( isBase == true )
          if ( whosBase == Black )
               aux = " is a black base; " ;
             else
                 aux = " is a red base; " ;
       output += aux;

       if ( isObstructed == true)
            aux = " is obstructed; " ;
          else
              aux =  " is clear; " ;
        output += aux;

        if ( bug == NULL )
                 aux = " contains no bug; ";
             else
                 {
                  color = bug -> GetColor();
                  if ( color == Black )
                             aux = " contains a black bug; " ;
                       else
                           aux = " contains a red bug; " ;
                  }
         output += aux;

    ss<<food<<flush;   ///outputs the number into the string stream and then flushes
                      /// the buffer (makes sure the output is put into the stream)
    output = output + " contains "+ ss.str() + " pieces of food; ";

    if ( redMarker > 0 ) /// if the int redmarker > 0 it means that the cell is marker with at least one marker
         output += " has a red marker; ";
    if ( blackMarker > 0 ) /// if the int blackmarker > 0 it means that the cell is marker with at least one marker
         output += " has a black marker; ";
	output += "\n";
return output;
}

void Cell::SetAdjCells(int direction, Cell* cel) ///Cel_StAjCe_argDirection)
{
    if (( direction < 0 ) || (direction > 5 )) throw "Cel_StAjCe_argDirection"; /// throws error for wrong direction value i.e <0 && >5

       else
       		adjCells[direction] = cel; /// sets the value of the pointer adjCells[direction] to ce
}
