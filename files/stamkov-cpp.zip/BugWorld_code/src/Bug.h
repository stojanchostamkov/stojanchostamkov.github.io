/** \file Bug.h 
 * \brief Implementation of the header file for the bug.
 *
 * This is the implementation of the bug. It was last worked on by
 * Stojanco Stamkov and Julian Fuerstenau (XP Phase 3).
 */

#ifndef __BUG_H__
#define __BUG_H__
#include <iostream>
#include <string>
#include <vector>
#include "../src/Cell.h"

namespace BugSim {
///forward declarations to avoid circularity
#pragma pointers_to_members(full_generality)
#ifndef __BUG_COLOR__
#define __BUG_COLOR__
/**
* \brief enum Color specifies the color of a bug or a color of a base 
*/
typedef enum {Red, Black, NoColor} Color;
#endif///__BUG_COLOR__

class Cell;


/**
* \brief The class representing a bug in the world
*
* This is the class which provides the methods for manipulating the bug's attributes
* in order to succesfully simulate the bug as specified in the specification files
*/  
class Bug
{
    private:
    /**
    *   Bug color, i.e. which team it belongs to
    */
        Color color;              
#ifndef DEBUG
    /**
    *   pointer to the cell that this instance of the Bug is in. If the DEBUG macro is not defined
    *   *cell stays private
    */
        Cell *cell;                 
#endif
    /**
    *   Direction the Bug is looking at
    */
        int direction;          
    /**
    *   state of the bug, i.e. state in its algorithm
    */
        int state;               
    /**
    *   units of resting that the Bug needs
    */
        int resting;         
    /**
    *   boolean value whether the Bug carries any food
    */
        bool hasFood;       
     /**
    *   boolean value indicating whether the bug is alive
    */
       bool isDead;        

    public:
#ifdef DEBUG
    /**
    *   pointer to the cell that this instance of the Bug is in. If the DEBUG macro is defined
    *   *cell becomes public instead of private, for debugging and testing purposes
    */
	     Cell* cell;
#endif
    /** \brief Bug constructor
	*
    *   \param color - color of the newly created bug
    *   \param cell - pointer to the cell where the bug is located
    */
        Bug(Color color, Cell *cell);
    /** \brief Method returning the enemy's color
	*
    *   \param color - Bug's own color
    *   \return the opposite color
    */
        Color OtherColor(Color color) const;
    /** \brief Getter method for color
	*
    *   \return the Bug's color
    */
        Color GetColor() const;
    /** \brief Getter method for state
	*
    *   \return the Bug's state
    */
        int GetState() const;
    /** \brief Setter method for state
	*
    *   \return the newState integer indicating the new state of the Bug
    */
        void SetState(int newState);
    /** \brief Getter method for food
	*
	*   \param The new state of the bug
    *   \return boolean value indicating whether the bug is carrying any food
    */
        bool HasFood() const;
    /** \brief Method that picks up food if available in the current cell
	*
    *  This method decrements the food value in the current cell if food is picked.
    *   \return  boolean value indicating whether it picked up food or not
    */
        bool PickupFood();
    /** \brief Method that drops food if the Bug is carrying any
	*
    *  This method increments the food value in the current cell if food is picked.
    *   \return a boolean value indicating whether it dropped food or not
    */
        bool DropFood();
    /** \brief Getter method for resting
	*
    *   \return an integer value indicating the current value of resting
    */
        int GetResting() const;
    /** \brief Setter method for resting
    *
    *   \param rest - value with which the current resting value is incremented
    */
        void IncrementResting(int rest);
    /** \brief Getter method for current direction
	*
    *   \return an integer value indicating the current direction the Bug is looking at
    */
        int GetDirection() const;
	/**new getter method that finds out if a bug is dead or not
	*/
		bool IsDead() const;
    /** \brief Setter method that turns the bug to the specified direction
	*
    *   returns the direction to turn to
    */
        void Turn(int direction);
    /** \brief Initializes the process of moving the bug to the current direction
	*
    *   This method checks if a move is possible and if yes
    *   sets the cell pointer in the bug to its new cell that contains the bug
    *   \param The direction in which the bug should turn
    *   \return a  boolean value indicating success of the move operation
    */
        bool Move();
    /** \brief Returns the color of the cell in the specified direction
	*
    *   Checks if the Cell in the specified direction is a base cell and then returns accordingly.
    *   \param direction - integer indicating the direction that we are interested in
    *   \return a Color showing the color of the cell if available, otherwise returns NoColor
    */
        Color WhosBase(int);
    /** \brief Method showing whether the cell in specified direction is obstructed.
	*
    *   \param direction - integer indiciating the direction
    *   \return a boolean value indicating whether the specified cell is obstructed or not
    */
        bool IsObstructed(int) const;
    /** \brief Method showing whether the cell in specified direction is base.
	*
    *   \param direction - integer indiciating the direction
    *   \return a boolean value indicating whether the specified cell is base or not
    */
        bool IsBase(int) const;
    /** \brief Method returning the available food in the specified cell if any.
	*
    *   \param direction - an integer indiciating the direction
    *   \return an integer value indicating number of food units in the specified cell
    */
        int GetFoodInCell(int) const;
	/** \brief Method showing whether the cell in specified direction is occupied.
	*
    *   \param direction - integer indiciating the direction
    *   \return a boolean value indicating whether the specified cell is occupied or not
    */
        bool IsOccupied(int) const;
    /** \brief Method showing the color of the bug in cell with the specified direction
    *
    *   \param direction - an integer indiciating the direction
    *   \return a Color value indicating the color of the Bug in the Cell, if no Bug is present there returns an error.
    */
        Color GetBugColorInCell(int) const;
    /** \brief Method showing whether the Bug in specified direction carries any food.
    *
    *   \param direction - integer indiciating the direction
    *   \return boolean value indicating whether the Bug carries any food, if no Bug is present there returns an error.
    */
        bool BugHasFoodInCell(int) const;
	/** \brief Method showing whether the following marker has been set
	*
    *   \param color - Color of the marker requested
    *   \param marker - type of marker requested
    *   \param direction - direction of the cell to be checked for the specified marker
    *   \return a boolean value indicating whether the requested marker is present
    */
        bool GetMarker(Color color, int marker, int) const;
    /** \brief Method showing whether the Cell in the specified direction is marked
    *
    *   \param color - Color of the marker requested
    *   \param direction - direction of the cell to be checked for the specified marker
    *   \return a boolean value indicating whether the Cell is marked or not
    */
        bool IsMarked(Color color, int direction) const;
    /** \brief Method that sets (on or off) the specified marker in the current cell
    *
    *   \param value - boolean indicating whether to set on or off the specified marker
    *   \param marker - type of maker to be set on or off
    */
        void SetMarker(bool value, int marker);
    /** \brief Method that kills the Bug if it got surrounded
    *
    *   Note: whether the Bug is surrounded is taken care of in the Cell class.
    */
        void Die();
};

} ///namspace BugSim

#endif///__BUG_H__
