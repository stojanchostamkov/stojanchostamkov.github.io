#include <iostream>
#include <vector>
#include <map>
#include "../src/Bug.h"
#include "../src/Cell.h"
#include "../src/Instruction.h"
#include "../src/Parser.h"

using namespace std;
using namespace BugSim;

    //defined in Parser.cpp

extern Parser* TheParser;

void printIvect(vector<Instruction*> &ivect) {
     unsigned int r;
     if (ivect.empty()) cout << "\nThe vector is empty.\n";
     else {
            for (r=0; r<ivect.size(); r++) {
        cout << "\nInstruction number " << r << endl;
        cout << "=======================\n";
        ivect[r]->printDebug();
           }
     }
}
     

int main() {
    

    string s1="../test/parser_files/parFile1";
    string s2="../test/parser_files/parFile2";
    string s3="../test/parser_files/parFile3";
    string s4="../test/parser_files/parFile4";
    string s5="../test/parser_files/parFile5";
    string s6="../test/parser_files/parFile6";
    string s7="../test/parser_files/parFile7";
    string s8="../test/parser_files/parFile8";
    string s9="../test/parser_files/parFile9";
    string s10="../test/parser_files/parFile10";
    string s11="../test/parser_files/parFile11";        //doesn't exist
    
   vector<Instruction*> ivect;
   cout << "Testing the parser method\n";
   cout << "****************************\n\n";
   
   cout << "\n>>>Parsing the first file<<<\n";
   ivect = TheParser->ParseInstructionFile(s1);
   printIvect(ivect);
   
   cout << "\n\n>>>Parsing the second file<<<\n";
   ivect = TheParser->ParseInstructionFile(s2);
   printIvect(ivect);

//Testing an incomplete file
   cout << "\n\n>>>Parsing the third file<<<\n";
   ivect = TheParser->ParseInstructionFile(s3);
   printIvect(ivect);

//Testing a file with a wrong instruction (1101) in instr. 6   
   cout << "\n\n>>>Parsing the fourth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s4);
   printIvect(ivect);

//Testing a file with a wrong sense instruction (not zero where specified)
   cout << "\n\n>>>Parsing the fifth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s5);
   printIvect(ivect);
   
//Testing a file with a wrong sense instruction (wrong condition 1111)
   cout << "\n\n>>>Parsing the sixth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s6);
   printIvect(ivect);
   
//Testing a file with a wrong mark instruction (wrong marker 110)
   cout << "\n\n>>>Parsing the seventh file<<<\n";
   ivect = TheParser->ParseInstructionFile(s7);
   printIvect(ivect);

//Testing a file with a wrong direction instruction (wrong direction 111)   
   cout << "\n\n>>>Parsing the eighth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s8);
   printIvect(ivect);
   
//Testing a file with a wrong target state (out of bounds, target: 11111, MaxState:10011)   
   cout << "\n\n>>>Parsing the nineth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s9);
   printIvect(ivect);
   
//Testing a file with a wrong goto instruction (not zero where specified)
   cout << "\n\n>>>Parsing the tenth file<<<\n";
   ivect = TheParser->ParseInstructionFile(s10);
   printIvect(ivect);

//Testing a file that doesn't exist
   cout << "\n\n>>>Parsing the eleventh file<<<\n";
   ivect = TheParser->ParseInstructionFile(s11);
   printIvect(ivect);   
   
cout << "\n\nTesting the instruction table\n";
cout << "*********************************\n";
//We have the following code in BinaryFormat.txt   
//sense_code     ::= 0000
//mark_code      ::= 0001
//unmark_code    ::= 0010
//pickup_code    ::= 0011
//drop_code      ::= 0100
//turn_code      ::= 0101
//move_code      ::= 0110
//flip_code      ::= 0111
//direction_code ::= 1000
//goto_code      ::= 1001

   TheParser->RegisterInstruction(0,"InstSense");
   TheParser->RegisterInstruction(1,"InstMark");
   TheParser->RegisterInstruction(2,"InstUnmark");
   TheParser->RegisterInstruction(3,"InstPickup");
   TheParser->RegisterInstruction(4,"InstDrop");
   TheParser->RegisterInstruction(5,"InstTurn");
   TheParser->RegisterInstruction(6,"InstMove");
//Should cause an error: Key lready in table
   TheParser->RegisterInstruction(3,"InstWrong");
   TheParser->RegisterInstruction(7,"InstFlip");
   TheParser->RegisterInstruction(8,"InstDirection");
   TheParser->RegisterInstruction(9,"InstGoTo");
//Should cause an error: Key lready in table
   TheParser->RegisterInstruction(9,"InstSomethingElse");

   cout << "\nPrinting the contents of the instruction table\n";   
   TheParser->print_table();


}
