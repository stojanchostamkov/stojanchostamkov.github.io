#include <iostream>
#include "../src/Bug.h"
#include "../src/Cell.h"
#include "../src/Instruction.h"

using namespace std;
using namespace BugSim;

int main() {
    
//Defining some cells and bugs that will be used in testing

     
     Cell b(false,9,true,Black);
     Cell c(false,0,true,Red);
     Cell d(false,6,false,NoColor);  
     Cell e(false,3,true,Red);
     Cell f(false,2,true,Black);
     Cell g(false,7,false,NoColor); 
     Cell h(false,2,true,Red);
     Cell i(false,0,true,Black);
     Cell j(false,4,false,NoColor); 
     
     Cell kk (false,1,false,NoColor);
     if (kk.IsOccupied()) cout << "kk is occupied now\n";

                                                           
     Bug bA1(Black, &c);
     Bug bA2(Black, &b);

     Bug bA3(Red, &d);     
     Bug bA4(Black, &e);
     Bug bA5(Black, &f);
     Bug bA6(Red, &g);
     Bug bA7(Black, &h);
     Bug bA8(Black, &i);


cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstGoTo*********************\n";

   
     bA1.SetState(13);
     cout << "The initial state of bA1 is "<< bA1.GetState() << endl;     
   
    
    int arrA1[1];
    arrA1[0]=34; //set the state to 34
    
    int arrA1b[1];
    arrA1b[0]=16; //set the state to 16
    
    //HERE IS MaxStates DEFINED
    //It will be used in the whole testing
    int MaxStates=3500;
    
    
    InstGoTo insA1(arrA1,MaxStates);       //instantiating
    //printing debug info
    insA1.printDebug();
    
    InstGoTo insA1b(arrA1b, MaxStates);   //instantiating                                                    
    //printing debug info    
    insA1b.printDebug(); 
 
    //Testing erroroneous input
    int arrA2[1];
    arrA2[0]=11251;
    InstGoTo insA2(arrA2,MaxStates);
    
    //Testing NewMe, which is a kind of a copy constructor
    InstGoTo insA3=insA1.NewMe(MaxStates);
    
    //Testing Execute
    insA1.Execute(bA1);
    cout << "The state of bA1 is "<< bA1.GetState() << endl;
    insA1b.Execute(bA1);
    cout << "The state of bA1 now is "<< bA1.GetState() << endl;    
    insA3.Execute(bA1);
    cout << "The state of bA1 now is "<< bA1.GetState() << " again, since we cloned the previous instruction\n";    
    


cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstMark*********************\n";
      
      
      int arrb1[2];
      int arrb2[2];

      arrb1[0]=4;     //marker  
      arrb1[1]=3411; //nextstate
      
      arrb2[0]=8;  //wrong marker value
      arrb2[1]=521;
      
      InstMark mark1(arrb1, MaxStates);
      InstMark mark2(arrb2, MaxStates); //wrong, but will let you instantiate such a value
                                        //it will, however, fail to Validate before Execute
      
      
      //printing debug information
      mark1.printDebug();
      mark2.printDebug();
      
      //in Execute, it checks for parsing errors and if there are nono
      //it executes the instruction
            
      if (mark1.Execute(bA2)==1)   //will return 0
         cout << "Parsing error. Failed to execute\n";

      if (mark2.Execute(bA3)==1) //will return 1, and print error
         cout << "Parsing error. Failed to execute\n";
      
      //Testing the set marker
      cout << "The state of bA2 is " << bA2.GetState() << endl;
      if (b.GetMarker(Black,4)) 
         cout << "There is a Black marker of value 4 in bA2's cell\n";

      //Testing the NewMe constructor
      InstMark mark3=mark1.NewMe(MaxStates);
      mark3.printDebug();
           
  
cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstUnmark*********************\n";
      
      
      InstUnmark unmark1(arrb1, MaxStates);
      InstUnmark unmark2(arrb2, MaxStates); //wrong, but will let you instantiate such a value
                                            //it will, however, fail to Validate before Execute
      
      
      //printing debug information
      unmark1.printDebug();
      unmark2.printDebug();
      
      //in Execute, it checks for parsing errors and if there are nono
      //it executes the instruction
            
      if (unmark1.Execute(bA2)==1)   //will return 0
         cout << "Parsing error. Failed to execute\n";

      if (unmark2.Execute(bA4)==1) //will return 1, and print error
         cout << "Parsing error. Failed to execute\n";
      
      //Testing the set marker
      cout << "The state of bA2 is " << bA2.GetState() << endl;
      if (!(b.GetMarker(Black,4))) 
         cout << "There is NO Black marker of value 4 in bA2's cell now\n";

      //Testing the NewMe constructor
      InstUnmark unmark3=unmark1.NewMe(MaxStates);
      unmark3.printDebug();  
                         

cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstTurn*********************\n";
                          
                    
      
      int arrT1[2];
      arrT1[0]=1;  //left or right
      arrT1[1]=345; //next state     
                          
      //The error handling procedure is same as the previous classes'
      
      InstTurn turn1(arrT1, MaxStates);
      turn1.printDebug();
      
      //before execution
      cout << "The direction of bug bA2 is " << bA2.GetDirection() << endl;      
      turn1.Execute(bA2);
      //after execution
      cout << "The direction of bug bA2 after moving right is " << bA2.GetDirection() << endl;      
      
      InstTurn turn2=turn1.NewMe(MaxStates);
      turn2.printDebug();
      
cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstSense********************\n";
      
      
      int arrS1[4];
      arrS1[0]= 0;          //sensing direction, meaning Here (see Instruction.h or documentation for details)
      arrS1[1]= 1224;          // success state
      arrS1[2]= 1225;          // failure state
      arrS1[3]= 13;          // condition code meaning Home (see Instruction.h or documentation for details)
      
      int arrS2[4];
      arrS2[0]= 3;          //sensing direction, meaning Ahead (see Instruction.h or documentation for details)
      arrS2[1]= 315;          // success state
      arrS2[2]= 615;          // failure state
      arrS2[3]= 6;          // condition code meaning Friend (see Instruction.h or documentation for details)

      //Instantiating instructions
      InstSense sense1(arrS1, MaxStates);
      sense1.printDebug();
      
      InstSense sense2(arrS2, MaxStates);
      sense2.printDebug();      
      
      //We know that
//     Bug bA5(Black, &f);
//     Bug bA6(Red, &g);
//     Cell f(false,2,true,Black);
//     Cell g(false,7,false,NoColor); 

      g.adjCells[0]=&f;
      b.adjCells[1]=&kk;
      
      
      sense1.Execute(bA5); //checks if Here, cell f is Home. Should be true
      cout << "The next state of bug bA5 is " << bA5.GetState() << endl;
      if (arrS1[1]==bA5.GetState()) 
         cout << "The condition was true. Cell HERE is HOME\n";
      else if (arrS1[2]==bA5.GetState())
           cout << "The condition was false\n";
           
      sense2.Execute(bA6); //check if the cell Ahead (that is cell f) is a Freind. Should be false

      cout << "The next state of bug bA6 is " << bA6.GetState() << endl;
      if (arrS2[1]==bA6.GetState()) 
         cout << "The condition was true. Cell AHEAD has contain FRIEND\n";
      else if (arrS2[2]==bA6.GetState())
           cout << "The condition was false. Cell AHEAD doesn't contain FRIEND\n";      
      
      InstSense sense3=sense2.NewMe(MaxStates);
      sense3.printDebug();

cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstFlip********************\n";
       
       
       int arrF1[3];
       arrF1[0]=5;        //integer p to get the random number from 0 to p-1
       arrF1[1]=313;      //if the random integer is zero state
       arrF1[2]=355;      //if the random integer is nonzero state
       
             //Instantiating instructions
      InstFlip flip1(arrF1, MaxStates);
      flip1.printDebug();
      
      // We will now compare the output for x of the number generator to the specifications
      //Including x0 to x99
      cout << "Expected output:\n\
      7193, 2932, 10386, 5575, 100, 15976, 430, 9740, 9449, 1636, 11030, 9848, 13965, 16051,\
      14483, 6708, 5184, 15931, 7014, 461, 11371, 5856, 2136, 9139, 1684, 15900, 10236, 13297,\
      1364, 6876, 15687, 14127, 11387, 13469, 11860, 15589, 14209, 16327, 7024, 3297, 3120, 842,\
      12397, 9212, 5520, 4983, 7205, 7193, 4883, 7712, 6732, 7006, 10241, 1012, 15227, 9910,\
      14119, 15124, 6010, 13191, 5820, 14074, 5582, 5297, 10387, 4492, 14468, 7879, 8839, 12668,\
      5436, 8081, 4900, 10723, 10360, 1218, 11923, 3870, 12071, 3574, 12232, 15592, 12909, 9711,\
      6638, 2488, 12725, 16145, 9746, 9053, 5881, 3867, 10512, 4312, 8529, 1576, 15803, 5498,\
      12730, 7397\n\n";
      int c1;
      for (c1=0; c1<100; c1++) {
          flip1.Execute(bA7);
          }
      cout << endl << endl;    
          //Testing the NewMe mathod
      InstFlip flip2=flip1.NewMe(MaxStates);    
      flip2.printDebug();


cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstMove********************\n";
 
       int arrM1[2];
       arrM1[0]=123;      //success state
       arrM1[1]=197;      //failure state
       
       InstMove move1(arrM1, MaxStates);
        move1.printDebug();
//     We know that:
//      g.adjCells[0]=&f;
//      Bug bA5(Black, &f);
//      Bug bA6(Red, &g);  
     
        move1.Execute(bA6);
        //shouldn't be successful
        if (arrM1[0]==bA6.GetState()) 
         cout << "The move was successful\n";
        else if (arrM1[1]==bA6.GetState())
           cout << "The move was NOT successful\n";

//      The current direction of bA2 is 1   
//      b.adjCells[1]=&kk;
//      Bug bA2(Black, &b);
        if (bA2.IsObstructed(Ahead)) cout << "bA2 is obstructed ahead\n";
        move1.Execute(bA2);

        //should be successful
        if (arrM1[0]==bA2.GetState()) 
         cout << "The move was successful\n";
        else if (arrM1[1]==bA2.GetState())
           cout << "The move was NOT successful\n";
               
        InstMove move2=move1.NewMe(MaxStates);
        move2.printDebug();

cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstPickup*******************\n";
                          
       
       int arrP1[2];
       arrP1[0]=123;      //success state
       arrP1[1]=197;      //failure state
       
       InstPickup pickup1(arrP1, MaxStates);
       pickup1.printDebug();
        
       pickup1.Execute(bA1);
               //shouldn't be successful
        if (arrP1[0]==bA1.GetState()) 
         cout << "The pickup was successful\n";
        else if (arrP1[1]==bA1.GetState())
           cout << "The pickup was NOT successful\n";
       
       pickup1.Execute(bA3);
               //should be successful
        if (arrP1[0]==bA3.GetState()) 
         cout << "The pickup was successful\n";
        else if (arrP1[1]==bA3.GetState())
           cout << "The pickup was NOT successful\n";
           
       InstPickup pickup2=pickup1.NewMe(MaxStates);
       pickup2.printDebug();
        

cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstDrop*******************\n";

       int arrD1[1];
       arrD1[0]=1141;      //next state
       
       InstDrop drop1(arrD1, MaxStates);
       drop1.printDebug();
        
       if (bA3.HasFood())
          cout << "bug bA3 currently has food\n";
          
       drop1.Execute(bA3);
       
       if (bA3.HasFood())
          cout << "bug bA3 currently has food\n";
          else cout << "bug bA3 currently has NO food\n";
           
       InstDrop drop2=drop1.NewMe(MaxStates);
       drop2.printDebug();                   


cout << "\n\n\
//***********************************************************\n\
//****************TESTING class InstDirection****************\n";

       int arrD2[3];
       
       arrD2[0]=1;  //the direction to check for
       arrD2[1]=121;      //success state
       arrD2[2]=17;       //failure state
       
       InstDirection dir1(arrD2, MaxStates);
       
       dir1.Execute(bA2);
                      //should be successful

        if (arrD2[1]==bA2.GetState()) 
         cout << "The direction check was true\n";
        else if (arrD2[2]==bA2.GetState())
           cout << "The direction check was NOT true\n";
           
       dir1.Execute(bA8);
                      //shouldn't be successful
        if (arrD2[1]==bA8.GetState()) 
         cout << "The direction check was true\n";
        else if (arrD2[2]==bA8.GetState())
           cout << "The direction check was NOT true\n";
           
           
           
        
    return 0;
}
