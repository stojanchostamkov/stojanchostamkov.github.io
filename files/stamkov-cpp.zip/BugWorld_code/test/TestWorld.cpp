/** \file TestWorld.cpp
 * \brief Tests the methods of world, as defined in Instruction.cpp
 *
 * All the methods are tested, and every error procedure that is implemented is tested
 */


#include <iostream>
#include <string>
#include <cassert>
#include "../src/World.h"
#include "../src/Cell.h"
#include "../src/Bug.h"

using namespace std;
using namespace BugSim;

int main()
{
//The test files
    string file1="../test/world_files/worldFile1";
    string file2="../test/world_files/worldFile2";
    string file3="../test/world_files/worldFile3";
    string file4="../test/world_files/worldFile4";
    string file5="../test/world_files/worldFile5";
    string file6="../test/world_files/worldFile6";
    string file7="../test/world_files/worldFile7";
    string file8="../test/world_files/worldFile8";
    string file9="../test/world_files/worldFile9";
    string file10="../test/world_files/worldFile10";
    string file11="../test/world_files/worldFile11";
    string file12="../test/world_files/worldFile12";
    string file13="../test/world_files/worldFile13";    
	cout << "Creating a testworld..."<<endl;

try {
    cout << "\n\n\n==================================\n";
    cout << "Opening file " << file1 << endl;
    cout << "==================================\n";
	World* testworld = new World(file1);
	cout << "World created!"<<endl;
    string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
//Testing the empty constructor
    World w1;
    cout << "\n\n*******************\nPrinting the empty world\n*******************\n";    
    worldstate = w1.GetStateOfTheWorld();
    cout << worldstate;	
//Testing the copy constructor here
    World w2((*testworld));
    cout << "\n\n*******************\nAnd printing a copy of the first world\n*******************\n";
    worldstate = w2.GetStateOfTheWorld();
    cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Unknown character          
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file2 << endl;
    cout << "==================================\n";
	World* testworld = new World(file2);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Wrong/inconsistent number of columns
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file3 << endl;
    cout << "==================================\n";
	World* testworld = new World(file3);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Wrong/inconsistent number of rows
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file4 << endl;
    cout << "==================================\n";
	World* testworld = new World(file4);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Should be OK
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file5 << endl;
    cout << "==================================\n";
	World* testworld = new World(file5);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Non-integer dimensions
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file6 << endl;
    cout << "==================================\n";
	World* testworld = new World(file6);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Invalid dimensions
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file7 << endl;
    cout << "==================================\n";
	World* testworld = new World(file7);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Unknown character
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file8 << endl;
    cout << "==================================\n";
	World* testworld = new World(file8);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Different number of red and black cells
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file9 << endl;
    cout << "==================================\n";
	World* testworld = new World(file9);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//inconsistent number of columns per line
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file10 << endl;
    cout << "==================================\n";
	World* testworld = new World(file10);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Wrong number of columns
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file11 << endl;
    cout << "==================================\n";
	World* testworld = new World(file11);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }

//Wrong number of rows in file
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file12 << endl;
    cout << "==================================\n";
	World* testworld = new World(file12);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught. World not created\n";
          }
          
//File doesn't exist
try {
    cout << "\n\n\n\n\n\n==================================\n";
    cout << "Opening file " << file13 << endl;
    cout << "==================================\n";
	World* testworld = new World(file13);
	cout << "World created!"<<endl;
	string worldstate = testworld->GetStateOfTheWorld();
	cout << worldstate;
    }
    
catch (string errstr) {
      cout << "Error!\n" << errstr << "\nWorld not created\n";
      }    
catch (...) {
          cout << "IO error caught, file does not exist. World not created\n";
          }



	return 0;
}
