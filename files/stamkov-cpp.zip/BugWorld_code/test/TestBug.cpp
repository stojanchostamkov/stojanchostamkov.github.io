/* \brief TestBug.cpp - tests the methods of bug
 *
 *created by Julian Fuerstenau and Stojanco Stamkov (XP Phase III).
 *Tests the methods of the bug that have no direct counterpart in cell,
 *i.e. depend on bug alone.
 */

#include <iostream>
#include <string>
#include <cassert>
#include "../src/Cell.h"
#include "../src/Bug.h"

using namespace std;
using namespace BugSim;

///prints Bug info
void printBugInfo(Bug *aBug);

///asserts bug attributes
void assertBug(Bug *aBug, Color color, int direction, int state, int resting, bool hasFood, bool isDead);
/**note that assertBug uses getter methods, we do not have to specifically test
*each of the getter methods used there. Even though it is a function, it is
*also a test case of the getter methods it uses.
*/





int main(int argc, char** argv){


	Cell* testcell = new Cell();

    ///checking constructor  Bug(Color color, Cell *cell);
    cout <<"\nBUG 1:"<<endl;
    Bug* bug1 = new Bug(Red,testcell);
    assertBug(bug1,Red,0,0,0,false,false);
    printBugInfo(bug1);


    ///checking SetState(Color color)
    cout <<"\nBUG 2 with modified sate:"<<endl;
    Bug* bug2 = new Bug(Red,testcell);
	bug2->SetState(255);
    assert(bug2->GetState() == 255);
    printBugInfo(bug2);



	///checking PickupFood()
	cout <<"\nBUG 3 after picking up food:"<<endl;
	Bug* bug3 = new Bug(Black,testcell);
	testcell->IncrementFood(3);
	bug3->PickupFood();
	assert(bug3->HasFood() == true);
	printBugInfo(bug3);


	///checking DropFood()
	cout <<"\nBUG 3 after dropping food:"<<endl;
	bug3->DropFood();
	assert(bug3->HasFood() == false);
	printBugInfo(bug3);


	///checking IncrementResting(int rest)
	cout <<"\nBUG 4 has to rest:"<<endl;
	Bug* bug4 = new Bug(Black,testcell);
	bug4->IncrementResting(14);
	assert(bug4->GetResting() == 14);
	printBugInfo(bug4);


	///checking Turn(int direction)
	cout <<"\nBUG 5 has turned:"<<endl;
	Bug* bug5 = new Bug(Red,testcell);
	bug5->Turn(1);
	assert(bug5->GetDirection() == 1);
	printBugInfo(bug5);


	///checking Die()
	cout <<"\nBUG 6 had to die:"<<endl;
	Bug* bug6 = new Bug(Red,testcell);
	bug6->Die();
	assert(bug6->IsDead() == true);
	printBugInfo(bug6);


    ///this message will only be printed if all assertions were valid.
    cout <<"------------------ Message -------------------"<<endl;
    cout <<"Congratulations! No exceptions raised, successful ";
    cout <<"completion of test cases for class Bug."<<endl;

    return 0;
}






///prints the contents of bug.
void printBugInfo(Bug *aBug){

    Color acolor = aBug->GetColor();
	Color aothercolor = aBug->OtherColor(acolor);
	int adirection = aBug->GetDirection();
	int astate = aBug->GetState();
	int aresting = aBug->GetResting();
	bool ahasFood = aBug->HasFood();
	bool aisDead = aBug->IsDead();


    cout <<"***********************************************************"<<endl;
    cout <<" Bug Detail: "<<endl;
    cout <<" color:		"<<acolor<<endl;
	cout <<" othercolor:	"<<aothercolor<<endl;
    cout <<" direction: 	"<<adirection<<endl;
    cout <<" state:   	"<<astate<<endl;
    cout <<" resting:   	"<<aresting<<endl;
    cout <<" hasFood:   	"<<ahasFood<<endl;
    cout <<" isDead:	"<<aisDead<<endl;
    cout <<"***********************************************************"<<endl;
}



///asserts bug attributes
void assertBug(Bug *aBug, Color color, int direction, int state, int resting, bool hasFood, bool isDead)
{
    assert(color == aBug->GetColor());
	assert(color != aBug->OtherColor(color));
    assert(direction == aBug->GetDirection());
   	assert(state == aBug->GetState());
	assert(resting == aBug->GetResting());
	assert(hasFood == aBug->HasFood());
	assert(isDead == aBug->IsDead());

}
