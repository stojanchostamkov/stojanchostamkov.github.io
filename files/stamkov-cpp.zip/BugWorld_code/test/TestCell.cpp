/* \brief TestCell.cpp - tests the methods of cell
 *
 *created by Julian Fuerstenau and Stojanco Stamkov (XP Phase III).
 *Tests the methods of the cell that have no direct counterpart in bug,
 *i.e. depend on cell alone.
 */

#include <iostream>
#include <string>
#include <cassert>
#include "../src/Cell.h"
#include "../src/Bug.h"

using namespace std;
using namespace BugSim;

///prints cell info
void printCellInfo(Cell *aCell,int marker);

///asserts cell attributes
void assertCell(Cell *aCell,int food, bool isBase,string whosBase,bool isObstructed);
/**�note that assertCell uses getter methods, we do not have to specifically test
*each of the getter methods used there. Even though it is a function, it is
*also a test case of the getter methods it uses.
*/



int main(int argc, char** argv){

    ///default constructor
    cout <<"\nCELL 1:"<<endl;
    Cell cell1;
    assertCell(&cell1,0,false,"noColor",false);
    printCellInfo(&cell1,0);


    ///checking parametrized constructor
    cout <<"\nCELL 2:"<<endl;
    Cell cell2(false,12,true,Red);
    assertCell(&cell2,12,true,"Red",false);
    printCellInfo(&cell2,1);

    ///checking IsOccupied()
    cout <<"\nCELL 3:"<<endl;
    Cell cell3(false,15,true,Red);
    assert(!cell3.IsOccupied());
    printCellInfo(&cell3,1);

    ///checking IsFree()
    cout <<"\nCELL 4:"<<endl;
    Cell cell4(false,0,true,Red);
    assert(cell4.IsFree());
    printCellInfo(&cell4,1);

    ///checking GetState()
    cout <<"\nCELL 5:"<<endl;
	cout <<"***********************************************************"<<endl;
    Cell cell5(true,0,true,Black);
    string cellinfo = cell5.GetState();
    cout << cellinfo;
	cout <<"***********************************************************"<<endl;

    ///checking SetMarker()
    cout <<"\nCell 6:"<<endl;
    Cell cell6(true,12,true,Black);
    cell6.SetMarker(Red,2,true);
	assert(true == cell6.GetMarker(Red,2));
	printCellInfo(&cell6,2);

    ///checking IncrementFood()
    cout <<"\nCell 7:"<<endl;
    Cell cell7(true,12,false,Black);
    cell7.IncrementFood(12);
    assertCell(&cell7,24,false,"noColor",true);
    printCellInfo(&cell7,2);







    ///this message will only be printed if all assertions were valid.
    cout <<"------------------ Message -------------------"<<endl;
    cout <<"Congratulations! No exceptions raised, successful ";
    cout <<"completion of test cases for class Cell."<<endl;

    return 0;
}


///prints the contents of cell.
void printCellInfo(Cell * aCell,int marker){

    int afood = aCell->GetFood();

    bool redMarker = aCell->GetMarker(Red,marker);
    bool blackMarker = aCell->GetMarker(Black,marker);
    string isBase;
    (aCell->IsBase())?(isBase="true"):(isBase="false");
    string whosBase;

	if(aCell->IsBase()){
	    if(aCell->WhosBase() == Red){
	        whosBase =="Red";
	    }
	    else if(aCell->WhosBase() == Black){
	        whosBase == "Black";
	    }
	}
	else {
	   	whosBase == "noColor";
	}



    string isObstructed;
    (aCell->IsObstructed())?(isObstructed="true"):(isObstructed="false");

    cout <<"***********************************************************"<<endl;
    cout <<" Cell Detail: "<<endl;
    cout <<" food:        "<<afood<<endl;
    cout <<" blackMarker: "<<blackMarker<<endl;
    cout <<" redMarker:   "<<redMarker<<endl;
    cout <<" isBase:      "<<isBase<<endl;
    cout <<" whosBase:    "<<whosBase<<endl;
    cout <<" isObstructed:"<<isObstructed<<endl;
    cout <<"***********************************************************"<<endl;
}

///asserts cell attributes
void assertCell(Cell *aCell,int food, bool isBase,string whosBase,bool isObstructed){
    assert(food == aCell->GetFood());
    assert(isBase == aCell->IsBase());
    if(isBase){
        if(aCell->WhosBase() == Red){
            assert(whosBase =="Red");
        }else if(aCell->WhosBase() == Black){
            assert(whosBase == "Black");
        }
    }else {
        assert(whosBase == "noColor");
    }
    assert(isObstructed == aCell->IsObstructed());
}
