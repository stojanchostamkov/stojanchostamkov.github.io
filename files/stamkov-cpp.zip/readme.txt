Here are some code samples that I thought you might find interesting.
The BugWorld_complete_code.zip file contains a training project which was developed as a part of the Software Engineering Lab in Spring 2006. It models a complete environment for "bugs", which can walk, sense, search for food, fight with other spicies etc, for detailed specifications please refer to the included pdf.

The second component, the Compiler directory contains the source code of a simple compiler,
used as a complement to the to the BugWorld project, and used to compile the bug instructions into a specific binary format. The compiler code is generated using Flex and Bison, with the source files Assembler.lpp and Assembler.ypp, respectively.