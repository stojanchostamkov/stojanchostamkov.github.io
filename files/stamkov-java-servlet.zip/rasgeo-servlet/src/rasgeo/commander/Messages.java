/** ***********************************************************
 *
 * SOURCE: rasgeo.commander.Messages
 *
 * PACKAGE: rasgeo.commander
 * CLASS:  Messages
 *
 * PURPOSE:
 * offers message texts, fetched from a properties file whose name
 * is provided during init.
 * Messages are identified by a nonnegative integer number.
 *
 * CHANGE HISTORY (append further entries):
 * when        who         what
 * ----------------------------------------------------------
 * 2007-jan-10 PB          cloned from navigator.Messages
 * 2007-jan-15 SS          integrated with the rest of the package
 * COMMENTS:
 * - when introducing/changing message identifiers, update property files consistently!
 * - implements singleton pattern
 *
 *
 *********************************************************** */

package rasgeo.commander;

import java.io.*;
import java.util.*;
import javax.servlet.*;

/**
* This class contains all the texts used in the Navigator (buttons and messages)
*/
// FIXME: replace constants, see also comments in msg file commander_msgs_en
public class Messages
{
	/**
	button labels, and all other page display text
	**/

	// admin panel 1..19
	public static final int AdminPanelText1              =   1;

	/// finally, the default used if no preoperties file can be found
	public static final String NO_TEXT = "(no text)";

        /// maximum number of digits we expect from an error number as typed into properties file
        private static final int MAX_DIGITS = 5;

	/**
	path+name of message properties file
	**/
	private static String messageFile = null;
	/**
	resource bundle for property file(s) containing error messages
	**/
        private static PropertyResourceBundle messages = null;

	/**
	initialize singleton object, just store message file name;
	message file read will lazily be done when needed
	**/
	public static void init( String msgFile )
	{
		messageFile = msgFile;
		Debug.talkSparse( "Messages::init(): setting message file name to " + msgFile );

	}

	/**
	get message text corresponding to numeric code
	initialize resource bundle if not done.
	**/
	public static String getMessage( int code )
	{
		// try to allocate resources (=message texts), if not done already
		if (messages==null)
		{
			// discover message resources from file name passed in web.xml
			try
			{
				// - open file
				// Note: cannot use ResourceBundle, because it can only read classpath dirs + subdirs
				File messageFileHandle = new File( messageFile );	// get a file handle
				FileInputStream messageStream = new FileInputStream( messageFileHandle );
				// - get error code list
				messages = new PropertyResourceBundle( (InputStream) messageStream );	// evaluate resources in property file
				Debug.talkSparse( "Messages::getMessage(): Exception message file " + messageFile + " successfully opened, file contains " + messageFileHandle.length() + " bytes." );
			}
			catch (IOException io)
			{
				Debug.talkCritical("Current dir is:"+System.getProperty("user.dir"));
				Debug.talkCritical( "Messages::getMessage( " + code + " ): IO warning: cannot read message file pertaining to resource " + messageFile + "; no texts will be available." );
				messages = null;
			}
			catch (MissingResourceException e)
			{
				Debug.talkCritical( "Messages::getMessage( " + code + " ): Missing resource warning: cannot find message file pertaining to resource " + messageFile + "; no texts will be available." );
				messages = null;
			}
			catch (Exception e)
			{
				Debug.talkCritical( "Messages::getMessage( " + code + " ): warning: general exception while trying to open message file " + messageFile + "; no texts will be available." );
				messages = null;
			}
		}

		// searchNumber is the numeric code, but successively extended with leading 0 until found...or not.
		String searchNumber = Integer.toString( code );
		// text as retrieved from resource file
		String resourceText = null;
		// try this number, and if not found with leading 0s, until we lose interest
		// ...but only if resource bundle initialization was successful
		while (messages !=null && resourceText == null && searchNumber.length() <= MAX_DIGITS)
		{
			try
			{
				// try to find text in resource
				resourceText = messages.getString( searchNumber );
			}
			catch (MissingResourceException e)
			{
				// if not, try with adding a leading 0
				searchNumber = "0" + searchNumber;
			}
		}

		if (resourceText==null)
			resourceText = NO_TEXT;

		Debug.talkVerbose( "Messages::getMessage( " + code + " ) -> " + resourceText );
		return( resourceText );
	}

	/**
	 *testbed
	 *for testing purposes, provide standalone facility
	 */
	public static void main( String[] args )
	{
		// --- parameter evaluation
		if (args.length != 2)
		{
			System.out.println( "usage: java _thisTestApplication_ propertyFile messageNumber" );
			System.exit(2);	// usage exit code, per Linux convention
		}

		// --- action
		init( args[0] );
		System.out.println( "TestMessages: msg file " + args[0] + ", code " + args[1] + " -> " + getMessage( Integer.parseInt(args[1]) ) );
	}

} // Messages
