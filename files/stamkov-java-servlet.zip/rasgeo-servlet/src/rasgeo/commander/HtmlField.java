/** ***********************************************************
 *
 * SOURCE: HtmlField.java
 *
 * PACKAGE: rasgeo.commander
 * CLASS: HtmlField
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-feb-16  SS        created
 *
 *********************************************************** */


package rasgeo.commander;

/**
 * This is a class describing an HTML field
 **/
public class HtmlField
{
	// --- instance variables -----------------------------------------

	/**
	 * The field name in HTML code
	 **/
	protected String HTMLname;

	/**
	 * The field description
	 **/
	protected String FieldDesc;

	/**
	 * Error message related to the field
	 **/
	protected String ErrorMesg;

	/**
	 * The value of the field
	 **/
	protected  String FieldValue;

	/**
	 * The data type of the field
	 **/
	protected  String FieldType;
	
	/**
	 * A flag showing whether the field is valid (error-free)
	 **/
	protected boolean FieldValid;
	
	// --- instance methods -------------------------------------------

	/**
	 * Empty constructor
	 **/
	public HtmlField()
	{
		HTMLname="";
		FieldDesc="";
		ErrorMesg="";
		FieldValue="";
		FieldType=null;
		FieldValid=false;
	}

	/**
	 * Constructor with all parameters
	 * @param name String
	 * @param desc String
	 * @param errm String
	 * @param value String
	 * @param type String
	 * @param valid boolean
	 **/
	public HtmlField(String name, String desc, String errm, String value, String type, boolean valid)
	{
		HTMLname=name;
		FieldDesc=desc;
		ErrorMesg=errm;
		FieldValue=value;
		FieldType=type;
		FieldValid=valid;
	}
	
	
	
	/**
	 * Performs validity checks on an input which is supposed to be an integer
	 * @param checkString The (integer-containing) string which needs to be checked
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	private static boolean checkInt(String checkString)
	throws InvalidInputException
	{
		//TODO check for size of int
		//check for empty/whitespace first
		if ((checkString == null) || (checkString.trim().length()==0)) 
			throw new InvalidInputException("Value is empty or whitespace");
		try
		{
			int i=Integer.parseInt(checkString,10); // make sure the string it's treated as decimal int
			return true;
		} 
		catch (NumberFormatException exception)
		{
			throw new InvalidInputException("Value is not an integer");
		}

	}
	
	
	/**
	 * Performs validity checks on an input which is supposed to be an integer
	 * @param checkString The (double-containing) string which needs to be checked
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	public static boolean checkFloat(String checkString)
	throws InvalidInputException
	{
		//TODO check for size of float
		//check for empty/whitespace first
		if ((checkString == null) || (checkString.trim().length()==0)) 
			throw new InvalidInputException("Value is empty or whitespace");
		try
		{
			float d=Float.parseFloat(checkString);
			return true;
		} 
		catch (NumberFormatException exception)
		{
			throw new InvalidInputException("Value is not a double");
		}

	}

	/**
	 * Performs validity checks on a string, checks for non-empty values
	 * @param checkString The string which needs to be checked
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	public static boolean checkString(String cString)
	throws InvalidInputException
	{
		//TODO check for length of string
		//check for empty/whitespace 
		if ((cString == null) || (cString.trim().length()==0))
			throw new InvalidInputException("Value is empty or whitespace");
		else return true;

	}

	/**
	 * Performs a check on on the value of a string, given the value and expected type
	 * @param value String
	 * @param type String
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	public static boolean checkField(String value, String type)
	throws InvalidInputException
	{
		if ("int".equals(type))
		{
			try
			{
				return checkInt(value);
			}
			catch (InvalidInputException e)
			{
				throw e;
			}
		}
		else if ("float".equals(type))
		{
			try
			{
				return checkFloat(value);
			}
			catch (InvalidInputException e)
			{
				throw e;
			}
		}
		else if ("string".equals(type))
		{
			try
			{
				return checkString(value);
			}
			catch (InvalidInputException e)
			{
				throw e;
			}
		}
		else
		{
			Debug.talkCritical("checkField(String, String) -- Type to check not implemented in HtmlField class");
			return false;
		}
		
	}
	
	/**
	 * Performs a check on on the value of a string, given the value and using
	 * the type from the class
	 * @param value
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	public boolean checkField(String value)
	throws InvalidInputException
	{
		try
		{
			return checkField(value, FieldType);
		}
		catch (InvalidInputException e)
		{
			throw e;
		}
	}
	
	/**
	 * Performs a check on on the value of a string, using the class parameters
	 * @return boolean
	 * @throws InvalidInputException
	 **/
	public boolean checkField()
	throws InvalidInputException
	{
		try
		{
			return checkField(FieldValue, FieldType);
		}
		catch (InvalidInputException e)
		{
			throw e;
		}
	}

}

