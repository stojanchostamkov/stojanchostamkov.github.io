/** ***********************************************************
 *
 * SOURCE: rasgeo.Globals
 *
 * PACKAGE: rasgeo.commander 
 * CLASS: Globals
 *
 * PURPOSE:
 * This interface contains a list of global definitions and values.
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-jan-05  PB        created
 * 2007-jan-15  SS        integrated with the rest of the package
 *
 *********************************************************** */

/*
 * CVS:
 *   $CVSfile: Globals.java,v $ $Revision: 1.1 $ $State: Exp $
 *   $Locker:  $ 
 */


package rasgeo.commander;

public interface Globals
{
	// --- program identification ----------------------------------

	/**
	 * Field COMMANDER_VERSION
	 */
	public static final String COMMANDER_VERSION        = "1.0";

	// --- keywords in the web deployment file ---------------------

	/**
	 * Field OPTION_JDBC_DATABASE_URL
	 */
	public static final String OPTION_JDBC_DATABASE_URL = "url";

	/**
	 * Field OPTION_JDBC_USER
	 */
	public static final String OPTION_JDBC_USER         = "user";

	/**
	 * Field OPTION_JDBC_PASSWD
	 */
	public static final String OPTION_JDBC_PASSWD       = "password";

	/**
	 * Field OPTION_JDBC_DRIVER
	 */
	public static final String OPTION_JDBC_DRIVER       = "driver";

	/**
	 * Field OPTION_DEBUG
	 */
	public static final String OPTION_DEBUG             = "debug";
	/**
	 * Field DEBUG_PARAM_NAME
	 */
	public static final String DEBUG_PARAM_NAME             = "debugLevel";

	/**
	 * Field OPTION_MSGFILE
	 */
	public static final String OPTION_MSGFILE           = "messageFile";

	// --- table and attribute names ------------------------------
	public static final String SERVICE                  = "Service";
	public static final String SERVICE_SERVICEID        = "serviceId";
	public static final String SERVICE_UPDATESEQUENCE   = "updateSequence";
	public static final String SERVICE_NAME             = "name";
	public static final String SERVICE_TITLE            = "title";
	public static final String SERVICE_ABSTRACT         = "abstract";
	public static final String SERVICE_KEYWORDS         = "keywords";
	public static final String SERVICE_FEES             = "fees";
	public static final String SERVICE_ACCESSCONSTRAINTS = "accessConstraints";
	public static final String SERVICE_HOSTNAME         = "hostName";
	public static final String SERVICE_PORT             = "port";
	public static final String SERVICE_PATH             = "path";
	public static final String SERVICE_FORMATS          = "formats";
	public static final String SERVICE_BASELAYERNAME    = "baseLayerName";
	public static final String SERVICE_VENDORCAPABILITIES = "vendorCapabilities";
	public static final String SERVICE_DBCONNECTION     = "dbConnection";
	/**
	 * Field SERVICE_ACTION_URL
	 * Here the URL of the applet which handles POST/GET requests is stored
	 * Afterwards, HTML forms will have their action parameter set to this
	 */
	public static final String SERVICE_ACTION_URL     = "RasgeoManager";
	

	public static final String DBCONN                   = "DatabaseConnection";

	public static final String LAYERS                   = "Layers";

	public static final String STYLES                   = "Styles";

	public static final String PYRAMIDLEVELS            = "PyramidLevels";

	// --- error messages -----------------------------------------
	// NB: will go into Messages.java

	public static final String ERROR_NO_JDBC_URL        = "Error: No JDBC URL specified in configuration file.";
	public static final String ERROR_NO_JDBC_USER       = "Error: No JDBC user specified in configuration file.";
	public static final String ERROR_NO_JDBC_PASSWD     = "Error: No JDBC password specified in configuration file.";
	public static final String ERROR_NO_JDBC_DRIVER     = "Error: No JDBC driver specified in configuration file.";

}

