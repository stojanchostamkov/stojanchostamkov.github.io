/************************************************************************
 *
 * SOURCE: rasgeo.RasgeoManager
 *
 * PACKAGE: rasgeo.commander 
 * CLASS: RasgeoManager
 *
 * PURPOSE
 * The servlet class. Displays the forms and HTML, defines the interface
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-feb-14  SS        created
 *
 * COMMENTS
 * 
 *
 *
 *********************************************************** */

package rasgeo.commander;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

import java.util.*;
import java.util.logging.ErrorManager;


/**
 * This class is the servlet class of the project. It displays the HTML pages,
 * connects the sub-pages and handles the POST/GET requests. Receives a connection to DB
 * from CommanderConnection and submits the query to the appropriate classes for execution
 **/
public class RasgeoManager extends HttpServlet implements Globals
{
	
	//TODO put them in an interface/class
	private static final String INS_PYRAMID_LEVID="ins_pyramid_levid";
	private static final String INS_PYRAMID_LAYID="ins_pyramid_layid";
	private static final String INS_PYRAMID_COLNAME="ins_pyramid_colname";
	private static final String INS_PYRAMID_SCALEF="ins_pyramid_scalef";
	private static final String INS_PYRAMID_POSTED="ins_pyramid_posted";
	private static final String INS_PYRAMID_FORM="ins_pyramid_form";
	
	/**
	 * A string for storing the name of the request handling servlet
	 * (the action attribute in the HTML form)
	 **/
	private static final String applet_action=Globals.SERVICE_ACTION_URL; 

	/**
	 * A string storing the JDBC URL, read in init() from the deployment file (web.xml)
	 * Made available for connectivity classes
	 **/
	public static String jdbc_url=null;
	
	/**
	 * A string storing the JDBC username, read in init() from the deployment file (web.xml)
	 * Made available for connectivity classes
	 **/
	public static String jdbc_user=null;
	
	/**
	 * A string storing the JDBC password, read in init() from the deployment file (web.xml)
	 * Made available for connectivity classes
	 **/
	public static String jdbc_password=null;
	
	/**
	 * A string storing the JDBC driver, read in init() from the deployment file (web.xml)
	 * Made available for connectivity classes
	 **/
	public static String jdbc_driver=null;	
		
	

	public void init( ServletConfig servletConfig )
	throws ServletException
	{
		super.init(servletConfig);	// do this before anything else!
		
		//TODO what is this for?
		//Config config = RasGeoConfig.getInstance();       		
		
		// set stream to this servlet's output -- doesn't work properly, PB 2003-dec-03
		Debug.setDebugChannel( this );
		Debug.talkCritical( Globals.COMMANDER_VERSION );
		Debug.enterCritical( "RasgeoManager.init()" );
		
		// get debug threshold value from web deployment file (web.xml)
		//default is CRITICAL_LEVEL
		int initDebugVal = Debug.CRITICAL_LEVEL;
		try
		{
			String initDebugString = getInitParameter( Globals.DEBUG_PARAM_NAME );
			initDebugVal = Integer.parseInt(initDebugString);
		}
		catch (NumberFormatException e)
		{
			// the following we want always in the log, even with level 0, therefore so dramatic:
			Debug.talkCritical( "init: Parameter debug not in servlet deployment file, using default " + initDebugVal);
		}
		Debug.setDebugThreshold( initDebugVal );
		Debug.talkSparse( "init: debug level threshold = " + initDebugVal );
	
		// get config parameter "message file" from web deployment file (web.xml)
		try
		{
			String messageFile = getInitParameter( Globals.OPTION_MSGFILE );
			Messages.init( messageFile );
		}
		catch(Exception e)
		{ 
			Debug.talkCritical( "Error: cannot read message properties file parameter '" + Globals.OPTION_MSGFILE + "': " + e.getMessage());
		}
	
		// get config parameter "my JDBC service URL" from web deployment file (web.xml)
		try
		{
			jdbc_url = getInitParameter( Globals.OPTION_JDBC_DATABASE_URL );
			if(jdbc_url == null)
				Debug.talkCritical( "Error: got null JDBC service URL parameter '" + Globals.OPTION_JDBC_DATABASE_URL );
		}
		catch(Exception e)
		{ 
			Debug.talkCritical( "Error: cannot read JDBC service URL parameter '" + Globals.OPTION_JDBC_DATABASE_URL + "': " + e.getMessage());
		}
	
		
		
		// get the JDBC username from web deployment file (web.xml)
		try
		{	
			jdbc_user = getInitParameter( Globals.OPTION_JDBC_USER );
			if(jdbc_user == null)
				Debug.talkCritical( "Error: got null JDBC user parameter '" + Globals.OPTION_JDBC_USER );
		}
		catch(Exception e)
		{
			Debug.talkCritical( "Error: cannot read JDBC user parameter '" + Globals.OPTION_JDBC_USER + "': " + e.getMessage());
		}	
		
		// get the JDBC password from web deployment file (web.xml)
		try
		{	
			jdbc_password = getInitParameter( Globals.OPTION_JDBC_PASSWD );
			if(jdbc_password == null)
				Debug.talkCritical( "Error: got null JDBC password parameter '" + Globals.OPTION_JDBC_PASSWD );
		}
		catch(Exception e)
		{ 
			Debug.talkCritical( "Error: cannot read JDBC password parameter '" + Globals.OPTION_JDBC_PASSWD + "': " + e.getMessage());
		}
		
		
		// get the JDBC driver from web deployment file (web.xml)
		try
		{	
			jdbc_driver = getInitParameter( Globals.OPTION_JDBC_DRIVER );
			if(jdbc_driver == null)
				Debug.talkCritical( "Error: got null JDBC driver parameter '" + Globals.OPTION_JDBC_DRIVER );
		}
		catch(Exception e)
		{ 
			Debug.talkCritical( "Error: cannot read JDBC driver parameter '" + Globals.OPTION_JDBC_DRIVER + "': " + e.getMessage());
		}
		
		
		Debug.leaveCritical( "RasgeoManager.init()" );
	}



	public void doGet(HttpServletRequest request,HttpServletResponse response)
	      throws ServletException, IOException
	{
		Debug.enterVerbose( "Commander.doGet()" );
	
		//TODO move into specific classes for each table
		
		
		/**
		 * Here all the fields of this page are stored
		 */
		HtmlField Fields[]={
				new HtmlField(INS_PYRAMID_LEVID, Messages.getMessage(500), "", "", "int", false),
				new HtmlField(INS_PYRAMID_LAYID, Messages.getMessage(501), "", "", "int", false),
				new HtmlField(INS_PYRAMID_COLNAME, Messages.getMessage(502), "", "", "string", false),
				new HtmlField(INS_PYRAMID_SCALEF, Messages.getMessage(503), "", "", "float", false),
				};
		
		/**
		 * A flag which shows whether the entry is complete, i.e. valid (true) or incomplete, i.e. invalid (false)
		 */
	  	boolean complete_entry=false;

		//if the form has been posted, check the values
		if ("true".equals(request.getParameter(INS_PYRAMID_POSTED)))
		{
			
			for (int i=0; i<Fields.length; i++)
			{
				try
				{
					Fields[i].FieldValid=Fields[i].checkField(request.getParameter(Fields[i].HTMLname));
					Fields[i].FieldValue=request.getParameter(Fields[i].HTMLname);
				}
				catch (InvalidInputException e) 
				{
					Fields[i].ErrorMesg="Error: "+e.msg;
//					ErrorMessage=ErrorMessage+"Error: "+e.msg+"<br />";
				}
			}

			//if all the entries are valid, set complete_entry to true
			for (int i=0; i<Fields.length; i++)
			{
				if (Fields[i].FieldValid)
					complete_entry=true;
				else
				{
					complete_entry=false;
					break;
				}
			}
			
		}

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>test</title>");
		out.println("</head>");
		out.println("<body>");
	
		out.println("<form name=\""+INS_PYRAMID_FORM+"\" method=\"POST\" action=\""+applet_action+"\">");
		//TODO make div and span class error message
		for (int i=0; i<Fields.length; i++)
		{
			out.println(Fields[i].FieldDesc+" <input type=\"text\" name=\""+Fields[i].HTMLname+"\" value=\""+Fields[i].FieldValue+"\"/><span>"+Fields[i].ErrorMesg+"</span><br />");
		}
		//this field indicates whether the form has been posted or not
		out.println("<input type=\"hidden\" name=\""+INS_PYRAMID_POSTED+"\"  value=\"true\"/><br>");
		out.println("<input type=\"submit\"/></form><br />");

		
		//Query should look like: INSERT INTO PyramidLevels (levelId, layerId, collectionName, scaleFactor) VALUES (3,5,'somechar',5.43);
		if (complete_entry)
		{
			
//			out.println("<UL>\n" +
//			"  <LI>param1: "
//			+ levID + "\n" +
//			"  <LI>param2: "
//			+ layID + "\n" +
//			"  <LI>param3: "
//			+ colName + "\n" +
//			"  <LI>param4: "
//			+ scaleF + "\n" +
//			"</UL>\n");
			
			String ErrorMessage="", SuccessMessage="";
			String query="INSERT INTO PyramidLevels (levelId, layerId, collectionName, scaleFactor) VALUES (" + Fields[0].FieldValue + "," + Fields[1].FieldValue + ",'" + Fields[2].FieldValue + "'," + Fields[3].FieldValue + ");";
//			String query2="INSERT INTO PyramidLevels (levelId, layerId, collectionName, scaleFactor) VALUES (" + levID+"0" + "," + layID+"0" + ",'" + colName + "'," + scaleF + ");";
		
		
			Debug.talkVerbose("doGet() - Trying to talk to database.");
			Debug.talkVerbose("EXECUTING INSERT STATEMENT ON PyramidLevels: "+query);
			CommanderConnection com_con=null;
			try
			{
				Debug.talkVerbose("doGet() - Connecting to database.");
				com_con=CommanderConnection.getInstance();
				Debug.talkVerbose("doGet() - Trying to execute update query.");
				com_con.executeUpdate(query);
				com_con.commit();
				SuccessMessage="Query executed succesfully";
				Debug.talkVerbose("doGet() - Succesfully executed update query.");
//				com_con=CommanderConnection.getInstance();
//				com_con.executeUpdate(query2);
//				com_con.commit();
//				com_con.close();

			}
			catch (SQLException se)
			{
				Debug.talkCritical("doGet() - Couldn't connect: printing out a stack trace.");
				Debug.talkCritical(se.toString());
				ErrorMessage="Could not write to database; please try again";
				
			}
			catch ( Exception e )
			{
				Debug.talkCritical("doGet() - Other connectivity exception: printing out a stack trace.");
				Debug.talkCritical(e.toString());
				ErrorMessage="Could not write to database; please try again";
						
			}
			//close the connection anyway
			finally
			{
				if(com_con!=null)
					try
					{
						com_con.close();
					}
					catch (ConnectionFailedException e)
					{
						Debug.talkCritical("doGet() - Couldn't disconnect-connection failed: printing out a stack trace.");
						Debug.talkCritical(e.toString());
					}
					catch (ConfigurationException e)
					{
						Debug.talkCritical("doGet() - Couldn't disconnect-configuration failed: printing out a stack trace.");
						Debug.talkCritical(e.toString());
					}
				
			}
			//TODO CSS classes for error messages and success messages
			//write the error message, if any
			out.println("<div>"+SuccessMessage+"</div>");
			//write the error message, if any
			out.println("<div>"+ErrorMessage+"</div></body></html>");

		}

		Debug.leaveVerbose( "Commander.doGet()" );
	} //doGet

  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException
  {
	Debug.enterVerbose( "Commander.doPost()" );
    doGet(request, response);
	Debug.leaveVerbose( "Commander.doPost()" );
  } //doPost


} //RasgeoManager class
