/** ***********************************************************
 *
 * SOURCE: ConnectionFailedException.java
 *
 * PACKAGE: rasgeo.commander
 * CLASS: ConnectionFailedException
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-jan-05  PB        created
 * 2007-jan-15  SS        integrated with the rest of the package
 *
 *********************************************************** */

/*
 * RCS:
 *   $RCSfile: BasicException.java,v $ $Revision: 1.1 $ $State: Exp $
 *   $Locker:  $ 
 */

package rasgeo.commander;

/**
 * ConnectionFailedException: error connecting to database
 */
public class ConnectionFailedException extends BasicException
{
	/**
	 * Constructor for ConnectionFailedException
	 * @param msg String
	 */
	public ConnectionFailedException( String msg )
	{
		super( msg );
	}

}


