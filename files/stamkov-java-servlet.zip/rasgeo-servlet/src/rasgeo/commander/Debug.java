/*************************************************************
 * <pre>
 *
 * SOURCE: BasicException.java
 *
 * PACKAGE: rasgeo.commander
 * CLASS: BasicException
 *
 * PURPOSE:
 * Generate debug output into servlet log.
 *
 * Methods of this static class perform debugging output into
 * the servlet log (usually /opt/jakarta/logs/servlet.log).
 * If not output channel is set, System.err will be used.
 *
 * For entering a method to be traced, logging indent level is
 * increased; the logging methods for leaving a method decrease
 * indent, and the trace methods inbetween leave indentation unchanged. 
 * [Needless to say that both statically and dynamically the number
 * of enters and leaves should match.]
 * Four trace levels are provided, intended for reporting increasingly
 * verbose (i.e., for decreasingly dangerous events):
 *	<LI>critical (always logged),
 *	<LI>warning (default level),
 *	<LI>sparse,
 *	<LI>verbose.
 * For each combination of enter/inside/leave of a method and trace
 * levels corresponding report functions are provided.
 * Finally, the debug level can be changed any time with
 * setDebugLevel().
 * Initialisation requires passing the servlet object to gain an
 * output stream to write to.
 *
 * CHANGE HISTORY (append further entries):
 * when        who         what
 * ----------------------------------------------------------
 * 2007-jan-15 SS    integrated with the rest of the package
 * COMMENTS:
 * - keep consistent with rasogc.Debug and rasj.Debug !!!
 *
 * </pre>
 ************************************************************/

package rasgeo.commander;
 
import javax.servlet.GenericServlet;			// to obtain servlet log output

public class Debug
{
	private static final String srcFileVersion = "CVS version information: $Source: /home/rasdev/CVS-repository/rasdaman/rasgeo/navigator/Debug.java,v $ $Revision: 1.2 $";

	/**
	 * enum values to be used as levels;
	 * higher values make output more unlikely
	 **/

	public static final int CRITICAL_LEVEL = 0;	// print always
	public static final int WARNING_LEVEL  = 1;
	public static final int SPARSE_LEVEL   = 2;
	public static final int VERBOSE_LEVEL  = 3;

	/**
	 * unit of indentation to display calling hierarchy
	 **/
	private static final String INDENT = ". ";

	/**
	 * * indentation counter
	 **/
	private static int indentLevel = 0;

	/**
	 * * debug threshold - only levels below it are displayed:
	 **/ 
	private static int debugThreshold = WARNING_LEVEL;		// this is default

	/**
	 * keeps servlet config object for log writing
	 **/
	private static GenericServlet streamKeeper = null;

	/**
	 * receives the servlet object to write log on
	 **/

	static void setDebugChannel( GenericServlet gs )
	{
		streamKeeper = gs;
	}

	/**
	 * set debug threshold to control further output
	 **/
	public static void setDebugThreshold(int level)
	{
		if (level >= 0)
			debugThreshold = level;
		else
			streamKeeper.log( "Debug::setDebugThreshold: ignoring illegal debug level value: " + level );
	}

	/**
	 * the following set of methods logs for entering/wintih/leaving a method.
	 * Entering increases printing indent level, talk leaves it unchanged, and leaving decreases indentation.
	 * these choices are crossed with the debug levels to achieve handy, short calls.
	 **/

	public static void enterCritical( String what )	{ enter( CRITICAL_LEVEL, what ); }
	public static void enterWarning( String what )	{ enter( WARNING_LEVEL,  what ); }
	public static void enterSparse( String what )	{ enter( SPARSE_LEVEL,   what ); }
	public static void enterVerbose( String what )	{ enter( VERBOSE_LEVEL,  what ); }

	public static void leaveCritical( String what )	{ leave( CRITICAL_LEVEL, what ); }
	public static void leaveWarning( String what )	{ leave( WARNING_LEVEL,  what ); }
	public static void leaveSparse( String what )	{ leave( SPARSE_LEVEL,   what ); }
	public static void leaveVerbose( String what )	{ leave( VERBOSE_LEVEL,  what ); }

	public static void talkCritical( String what )	{ talk( CRITICAL_LEVEL, what ); }
	public static void talkWarning( String what )	{ talk( WARNING_LEVEL,  what ); }
	public static void talkSparse( String what )	{ talk( SPARSE_LEVEL,   what ); }
	public static void talkVerbose( String what )	{ talk( VERBOSE_LEVEL,  what ); }

	/**
	 * writes messages to the "standard" error log stream, increments indentation
	 **/
	private static void enter(int level, String what)
	{
		StringBuffer s = new StringBuffer(100);				// to hold indent prefix

		if(level <= debugThreshold)
		{
			indentLevel++;						// indent one more to the right
			s.append( "[" + Integer.toString(level) + "] " );	// document log level
			for (int i=0; i<indentLevel; i++)
				s.append( INDENT );
			s.append( "ENTER " + what );
			if (streamKeeper != null)
				streamKeeper.log( s.toString() );
			else
				System.err.println( s );
		}
	}


	/**
	 * writes messages to the "standard" error log stream, decrements indentation
	 **/
	static void leave(int level, String what)
	 {
		StringBuffer s = new StringBuffer(100);				// to hold indent prefix

		if(level <= debugThreshold)
		{
			s.append( "[" + Integer.toString(level) + "] " );	// document log level
			for (int i=0; i<indentLevel; i++)
				s.append( INDENT );
			s.append( "LEAVE " + what );
			if (streamKeeper != null)
				streamKeeper.log( s.toString() );
			else
				System.err.println( s );
			indentLevel--;						// indent one less, go left
		}
	}

	/**
	 * writes messages to the "standard" error log stream; indentation unchanged
	 **/
	static void talk(int level, String what)
	{
		StringBuffer s = new StringBuffer(100);				// to hold indent prefix

		if(level <= debugThreshold)
		{
			s.append( "[" + Integer.toString( level) + "] " );	// document log level
			for (int i=0; i<indentLevel; i++)
				s.append( INDENT );
			s.append( what );
			if (streamKeeper != null)
				streamKeeper.log( s.toString() );
			else
				System.err.println( s );
		}
	}
}
