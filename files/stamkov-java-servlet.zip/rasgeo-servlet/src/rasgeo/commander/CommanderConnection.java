/************************************************************************
 *
 * SOURCE: rasgeo.CommanderConnection
 *
 * PACKAGE: rasgeo.commander 
 * CLASS: CommanderConnection
 *
 * PURPOSE
 * maintains database connection, using the Singleton patternn.
 * The connection is opened and closed explicitly.
 * The class discloses the SQL Statement objects as abstract units, ie,
 * not intended for direct database handling bypassing CommanderConnection.
 * Statement processing is available for both parametrized, prepared queries
 * and for ad-hoc queries (parametrized NOT YET).
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-feb-14  SS        modified to work with the local configuration
 *
 * COMMENTS
 *
 *
 *********************************************************** */

package rasgeo.commander;

import java.io.*;
import java.sql.*;
import java.util.Properties;

import rasgeo.commander.*;


/**
 * This class represents one connection to the underlying DBMS. It offers a set of 
 * prepared statements for querying the meta-tables and means for executing
 * arbitrary queries.
 **/
public class CommanderConnection
{
	/**
	 * An instance of CommanderConnection; singleton object
	 **/
	private static CommanderConnection comm_inst = null;
	
	/**
	 * An instance of a connection, managed by the singleton comm_inst
	 **/
	private Connection db_conn=null;

	/// login properties keywords, used for JDBC DriverManager initialization
	public final static String PROPERTY_USER     = "user";
	public final static String PROPERTY_PASSWORD = "password";
	
	//Gets these from RasgeoManager, which reads them from web.xml
	public static String JDBC_URL;
	public static String JDBC_USER;
	public static String JDBC_PASSWORD;
	public static String JDBC_DRIVER;
	
	/**
	 * singleton accessor
	 * @return Connection
	 * @throws ConnectionFailedException
	 * @throws ConfigurationException
	 */
	public static CommanderConnection getInstance()
		throws ConnectionFailedException, ConfigurationException
	{
		Debug.enterVerbose( "CommanderConnection.getInstance()" );	// ornament all public methods like that

		if (comm_inst == null)
			comm_inst=new CommanderConnection();

		Debug.leaveVerbose( "CommanderConnection.getInstance()" );
		return comm_inst;
	}

	/**
	 * Returns the connection object (and allocates one, if not yet initialized)
	 * Also, receives the connection parameters from RasgeoManager class
	 * @return CommanderConnection
	 * @throws ConnectionFailedException
	 * @throws ConfigurationException
	 **/
	private CommanderConnection( )
		throws ConnectionFailedException, ConfigurationException
	{
		
			JDBC_URL = RasgeoManager.jdbc_url;
			JDBC_USER = RasgeoManager.jdbc_user;
			JDBC_PASSWORD = RasgeoManager.jdbc_password;
			JDBC_DRIVER = RasgeoManager.jdbc_driver;
			if (JDBC_URL == null || JDBC_USER == null || JDBC_PASSWORD == null || JDBC_DRIVER == null)
			{
				String msg="Error: empty JDBC parameter recieved: Check the url, username, password, and JDBC driver parameters in your configuration.";
				Debug.talkCritical("CommanderConnection() --"+msg);
				throw new ConfigurationException(msg);
			}
			
			open( JDBC_URL, JDBC_USER, JDBC_PASSWORD, JDBC_DRIVER );	// modifies conn

	}

	/**
	 * Establish database connection;
	 * to this end, get some information from the config-class (e.g. JDBC-URL, user, passwd)
	 **/
	public void open( String url, String usr, String pwd, String jdbc )
		throws ConnectionFailedException, ConfigurationException
	{
		Debug.enterVerbose( "open()" );

		// if there is already a connection then try to close it first
		if (db_conn != null)
		{
			try
			{
				comm_inst.close();
			}
			catch( ConnectionFailedException c1 )
			{
				Debug.talkWarning( "Warning: JDBC error during force-close of connection for reopen: " + c1.getMessage() );
			}
			catch( ConfigurationException c2 )
			{
				Debug.talkWarning( "Warning: JDBC error during force-close of connection for reopen: " + c2.getMessage() );
			}
		}

		try
		{
			// determine JDBC driver class
			Debug.talkVerbose( "Getting Class.forName('" + jdbc + "')" );
			Class.forName(jdbc);

			// setup login credentials
			Properties pro = new Properties();
			pro.setProperty( PROPERTY_USER, usr );
			pro.setProperty( PROPERTY_PASSWORD, pwd );

			// open connection
			Debug.talkWarning( "Opening connection for url '" + url + "' using driver {" + jdbc + "} and properties '"  + pro  + "'" );
			db_conn = DriverManager.getConnection( url, pro );
			Debug.talkVerbose( "Connection sucessfully established." );

			// deactivate auto-commit mode
			db_conn.setAutoCommit( false );
			Debug.talkVerbose( "Auto-commit mode disabled." );

			// set transaction isolation level
			db_conn.setTransactionIsolation( Connection.TRANSACTION_READ_COMMITTED );
			Debug.talkVerbose( "Transaction isolation level set to READ COMMITTED." );
		}
		catch (SQLException e1)
		{
			String msg = "Error: Unable to open connection to '" + url + "': " + e1.getMessage();
			Debug.leaveVerbose( "open() -- " + msg );
			throw new ConnectionFailedException(msg);
		}
		catch (java.lang.ClassNotFoundException e2)
		{
			String msg = "Error: Could not find JDBC-driver: " + e2.getMessage();
			Debug.leaveVerbose( "open() -- " + msg );
			throw new ConnectionFailedException(msg);
		}

		Debug.leaveVerbose( "open()" );
	}

	/**
	 * Closes the connection.
	 * @throws ConnectionFailedException
	 **/
	public void close()
		throws ConnectionFailedException, ConfigurationException
	{
		Debug.enterVerbose( "close()" );
		
		if (db_conn != null)
		{
			try
			{
				db_conn.close();
				
			}
			catch (SQLException e1)
			{
				String msg = "Error: Could not close connection: " + e1.getMessage();
				Debug.leaveVerbose( "close() -- " + msg );
				throw new ConnectionFailedException( msg );
			}
		}
		comm_inst=null;
		Debug.leaveVerbose( "close()" );
	}

	/**
	 * auxiliary method printWarningsIfAny()
	 * writes eventual SQL warnings as trace output into system log
	 * @param stmt the statement to be analysed for warnings; pass null to ignore
	 */
	void printWarningsIfAny( Statement stmt )
	{
		if (stmt != null)
		{
			try
			{
				SQLWarning warning = stmt.getWarnings();
				if (warning != null)
				{
					Debug.talkWarning("Warning(s) issued by JDBC:");
					while (warning != null)
					{
						Debug.talkWarning( "\tMessage: " + warning.getMessage() );
						Debug.talkWarning( "\tSQLState: " + warning.getSQLState() );
						Debug.talkWarning( "\tVendor error code: " +  warning.getErrorCode() );
						warning = warning.getNextWarning();
					}
				}
	
				ResultSet rs = stmt.getResultSet();
				if (rs != null)
				{
					SQLWarning warn = rs.getWarnings();
					if (warn != null)
					{
						Debug.talkWarning("Warning(s) issued by JDBC:");
						while (warn != null)
						{
							Debug.talkWarning("\tMessage: " + warn.getMessage() );
							Debug.talkWarning("\tSQLState: " + warn.getSQLState() );
							Debug.talkWarning("\tVendor error code: " + warn.getErrorCode() );
							warn = warn.getNextWarning();
						}
					}
				}
			}
			catch (SQLException e1)
			{
				Debug.talkWarning( "Warning: caught SQLException during analysis of SQL warning." );
			}
		}
	}

	/**
	 * Executes any SQL update or insert statement.
	 * Note that there is no prepared update/insert, as this is not performance critical.
	 * @param query String
	 * @throws SQLException
	 **/
	public void executeUpdate(String query) throws SQLException
	{
		Statement statement = db_conn.createStatement();
		statement.executeUpdate(query);
		statement.close();
	}

	/**
	 * Commits a transaction (non-null connection only).
	 * @throws SQLException
	 **/
	public void commit() throws SQLException
	{
		Debug.enterVerbose( "commit()" );

		if (db_conn == null)
			Debug.talkCritical( "Warning: ignoring attempt to commit TA on null connection object.");
		else
		{
			try
			{
				db_conn.commit();
			}
			catch ( SQLException e )
			{
				Debug.talkCritical( "Error: SQLException during commit: " + e.getMessage() );
			}
		}

		Debug.leaveVerbose( "commit()" );
	}

	/**
	 * Aborts a transaction.
	 **/
	public void abort()
	{
		Debug.enterVerbose( "abort()" );

		if (db_conn == null)
			Debug.talkCritical( "Warning: ignoring attempt to abort TA on null connection object.");
		else
		{
			try
			{
				db_conn.rollback();
			}
			catch (SQLException e)
			{
				Debug.talkCritical( "Error: SQLException during rollback: " + e.getMessage() );
			}
		}

		Debug.leaveVerbose( "abort()" );
	}

	/**
	 * Method toString
	 * @return String
	 */
	public String toString()
	{
		String stringRepresentation = "CommanderConnection()";	// no relevant instance variables as for now
		return( stringRepresentation );
	}
	
/* we'll do that later. basics first...
	/**
	 * Executes a prepared statement.
	 * @param stmt <UL>
	 * the statement to be executed. These statements are defined as constants in class 
	 * {@link Globals}.</UL>
	 * @param key1 the first query parameter
	 * @param key2 the second query parameter
	 * @return ResultSet
	 * @throws SQLException
	 **
	public ResultSet executePreparedStatement(byte stmt, int key1, int key2)
		throws SQLException
	{
		prepStatement[stmt].clearParameters();
		prepStatement[stmt].setInt(1, key1);
		prepStatement[stmt].setInt(2, key2);
		return prepStatement[stmt].executeQuery();
	}

	/**
	 * Returns a prepared statement object.
	 * @param stmt String
	 * @return PreparedStatement
	 * @throws SQLException
	 **
	public PreparedStatement prepareStatement( String query ) throws SQLException
	{
		return conn.prepareStatement( query );
	}

	public Statement createStatement()
		throws ConnectionFailedException, SQLException
	{
		return( conn.createStatement( ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY) );
	}

	/**
	 * Method execute
	 * @param query
	 * @return ResultSet
	 * @throws SQLException
	 *
	public ResultSet execute( String query )
		throws SQLException
	{
		Debug.enterVerbose( "execute()" );

		Statement stmt = conn.createStatement();
		ResultSet result = stmt.executeQuery( query );

		Debug.leaveVerbose( "execute()" );
		return( result );
	}

	/**
	 * Method closeStatement
	 * @param stmt statement to be closed
	 * @throws SQLException
	 *
	public void closeStatement( Statement stmt ) throws SQLException
	{
		Debug.enterVerbose( "closeStatement( _ ) )" );

		if (stmt == null)
			Debug.talkWarning( "Warning: ignoring attempt to close null statement." );
		else
		{
			if (stmt.getResultSet() != null)
				stmt.getResultSet().close();
			stmt.close();
			printWarningsIfAny( stmt );
		}

		Debug.leaveVerbose( "closeStatement( _ ) )" );
	}
*/



	/**
	 * main() for standalone testing
	 * @param String url database URL
	 * @param String user database login name
	 * @param String password database login password
	 * @param String jdbc database JDBC connectivity
	 */
//	public static void main( String[] args )
//	{
//		Debug.setDebugThreshold( Debug.VERBOSE_LEVEL );
//		Debug.enterCritical( "class CommanderConnection component test" );
//
//		// --- cmd line parameter check ------------------------
//		if (args.length != 4)
//		{
//			Debug.leaveCritical( "Usage: CommanderConnection url user password jdbc" );
//			return;
//		}
//		String url  = args[0];
//		String usr  = args[1];
//		String pwd  = args[2];
//		String jdbc = args[3];
//		Debug.talkCritical( "Parameters used: url=" + url + ", user=" + usr + ", password=" + pwd + ", jdbc=" + jdbc );
//
//		try
//		{
//			// --- START preparation -----------------------
//			// none here.
//			// --- END preparation -------------------------
//	
//			// --- START test connection handling ----------
//			// - plain open, good case
//			CommanderConnection c = CommanderConnection.getInstance();
//			c.open( url, usr, pwd, jdbc );
//			c.close();
//
//			// - bad case: already open
//			c.open( url, usr, pwd, jdbc );
//			c.open( url, usr, pwd, jdbc );
//			c.close();
//
//			// - bad case: illegal parameters (null)
//			c.open( null, null, null, null );
//
//			// - bad case: illegal parameters (random values)
//			c.open( "param_1", "param_2", "param_3", "param_4" );
//			c.open( url, usr, pwd, jdbc );
//
//			// --- END test connection handling ------------
//
//			// --- START cleanup ---------------------------
//			c.close();
//			c = null;	// ...and check what happens at object freeing
//			// --- END cleanup -----------------------------
//		}
////		catch( SQLException e1 )
////		{
////			Debug.talkCritical( "Error: received SQLException during test execution: " + e1.getMessage() );
////		}
//		catch( ConnectionFailedException e2 )
//		{
//			Debug.talkCritical( "Error: received ConnectionFailedException during test execution: " + e2.getMessage() );
//		}
//		catch( ConfigurationException e3 )
//		{
//			Debug.talkCritical( "Error: received ConfigurationException during test execution: " + e3.getMessage() );
//		}
//
//		Debug.leaveCritical( "class CommanderConnection component test" );
//	}
}
