/** ***********************************************************
 *
 * SOURCE: InvalidInputException.java
 *
 * PACKAGE: rasgeo.commander
 * CLASS: InvalidInputException
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-feb-15  SS        created
 *
 *
 *********************************************************** */


package rasgeo.commander;

/**
 * InvalidInputException: invalid input passed from web form
 */
public class InvalidInputException extends BasicException
{
	/**
	 * Constructor for ConnectionFailedException
	 * @param msg String
	 */
	public InvalidInputException( String msg )
	{
		super( msg );
	}

}


