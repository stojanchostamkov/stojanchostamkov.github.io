/** ***********************************************************
 *
 * SOURCE: ConfigurationException.java
 *
 * PACKAGE: rasgeo.commander
 * CLASS: ConfigurationException
 *
 * CHANGE HISTORY (append further entries):
 * when         who       what
 * ----------------------------------------------------------
 * 2007-jan-05  PB        created
 * 2007-jan-15  SS        integrated with the rest of the package
 *
 *********************************************************** */

/*
 * RCS:
 *   $RCSfile: BasicException.java,v $ $Revision: 1.1 $ $State: Exp $
 *   $Locker:  $ 
 */

package rasgeo.commander;

/**
 * ConfigurationException: error evaluating configuration file
 */
public class ConfigurationException extends BasicException
{
	/**
	 * Constructor for ConfigurationException
	 * @param msg String
	 */
	public ConfigurationException( String msg )
	{
		super( msg );
	}

}

